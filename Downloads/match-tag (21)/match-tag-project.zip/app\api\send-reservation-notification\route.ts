import { NextRequest, NextResponse } from "next/server"

export async function POST(request: NextRequest) {
  try {
    const { 
      customerName, 
      customerEmail, 
      customerPhone, 
      reservationDate, 
      reservationTime, 
      tableNumber, 
      partySize,
      barName = "Nuestro Restaurante"
    } = await request.json()

    console.log("📧 Enviando notificación de reserva:", {
      customerName,
      customerEmail,
      customerPhone,
      reservationDate,
      reservationTime,
      tableNumber,
      partySize
    })

    // Formatear fecha y hora
    const date = new Date(reservationDate)
    const formattedDate = date.toLocaleDateString('es-ES', {
      weekday: 'long',
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    })

    // Preparar mensaje
    const message = `¡Hola ${customerName}! 🎉

Tu reserva ha sido confirmada:

📅 Fecha: ${formattedDate}
🕐 Hora: ${reservationTime}
🪑 Mesa: ${tableNumber}
👥 Personas: ${partySize}

¡Esperamos verte pronto en ${barName}! 

Si necesitas hacer algún cambio, por favor contáctanos.

¡Gracias por elegirnos! 🙏`

    const results = []

    // Enviar email si se proporciona
    if (customerEmail) {
      try {
        const emailResult = await sendEmail({
          to: customerEmail,
          subject: `✅ Reserva Confirmada - ${barName}`,
          text: message,
          html: `
            <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
              <h2 style="color: #2563eb;">¡Reserva Confirmada! 🎉</h2>
              <p>Hola <strong>${customerName}</strong>,</p>
              <p>Tu reserva ha sido confirmada exitosamente:</p>
              <div style="background-color: #f8fafc; padding: 20px; border-radius: 8px; margin: 20px 0;">
                <p><strong>📅 Fecha:</strong> ${formattedDate}</p>
                <p><strong>🕐 Hora:</strong> ${reservationTime}</p>
                <p><strong>🪑 Mesa:</strong> ${tableNumber}</p>
                <p><strong>👥 Personas:</strong> ${partySize}</p>
              </div>
              <p>¡Esperamos verte pronto en <strong>${barName}</strong>!</p>
              <p>Si necesitas hacer algún cambio, por favor contáctanos.</p>
              <p>¡Gracias por elegirnos! 🙏</p>
            </div>
          `
        })
        results.push({ type: 'email', success: true, result: emailResult })
        console.log("✅ Email enviado exitosamente")
      } catch (error) {
        console.error("❌ Error enviando email:", error)
        results.push({ type: 'email', success: false, error: error.message })
      }
    }

    // Enviar SMS si se proporciona
    if (customerPhone) {
      try {
        const smsResult = await sendSMS({
          to: customerPhone,
          message: message
        })
        results.push({ type: 'sms', success: true, result: smsResult })
        console.log("✅ SMS enviado exitosamente")
      } catch (error) {
        console.error("❌ Error enviando SMS:", error)
        results.push({ type: 'sms', success: false, error: error.message })
      }
    }

    return NextResponse.json({ 
      success: true, 
      message: "Notificaciones enviadas",
      results 
    })

  } catch (error) {
    console.error("❌ Error en API de notificaciones:", error)
    return NextResponse.json(
      { success: false, error: "Error interno del servidor" },
      { status: 500 }
    )
  }
}

// Función para enviar email (usando Resend o similar)
async function sendEmail({ to, subject, text, html }: {
  to: string
  subject: string
  text: string
  html: string
}) {
  // Por ahora simulamos el envío
  // En producción, integrar con Resend, SendGrid, o similar
  console.log("📧 Simulando envío de email:", { to, subject })
  
  // Simular delay de API
  await new Promise(resolve => setTimeout(resolve, 1000))
  
  return { messageId: `email_${Date.now()}` }
}

// Función para enviar SMS (usando Twilio o similar)
async function sendSMS({ to, message }: {
  to: string
  message: string
}) {
  // Por ahora simulamos el envío
  // En producción, integrar con Twilio, AWS SNS, o similar
  console.log("📱 Simulando envío de SMS:", { to, message: message.substring(0, 50) + "..." })
  
  // Simular delay de API
  await new Promise(resolve => setTimeout(resolve, 1000))
  
  return { messageId: `sms_${Date.now()}` }
}
