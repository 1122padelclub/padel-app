"use client"

import { useEffect, useState } from "react"
import { useSearchParams } from "next/navigation"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { InterTableChatWindow } from "@/src/components/InterTableChatWindow"
import { TablePasswordPrompt } from "@/src/components/TablePasswordPrompt"
import { ThemeProvider } from "@/src/components/ThemeProvider"
// Removed Firebase dependencies
import { useAutoMigration } from "@/src/hooks/useAutoMigration"
import { useTableAuth } from "@/src/hooks/useTableAuth"
import { useSimpleTable } from "@/src/hooks/useSimpleTable"
import { useSimpleBar } from "@/src/hooks/useSimpleBar"
import { useAdminTables } from "@/src/hooks/useAdminTables"
import { useRobustTables } from "@/src/hooks/useRobustTables"

function MesaContent() {
  const searchParams = useSearchParams()
  const [barId, setBarId] = useState<string | null>(null)
  const [tableId, setTableId] = useState<string | null>(null)
  const [tableNumber, setTableNumber] = useState<number | null>(null)
  const [barLogo, setBarLogo] = useState<string | null>(null)
  const [isChatOpen, setIsChatOpen] = useState(false)
  const [loading, setLoading] = useState(true)
  const [tablePassword, setTablePassword] = useState<string | null>(null)
  const [isPasswordRequired, setIsPasswordRequired] = useState(false)
  const [isAuthenticated, setIsAuthenticated] = useState(false)
  const [passwordError, setPasswordError] = useState("")

  const migration = useAutoMigration(barId)
  const tableAuth = useTableAuth()
  const { table: simpleTable, loading: tableLoading } = useSimpleTable(barId, tableId)
  const { bar: simpleBar, loading: barLoading } = useSimpleBar(barId)
  
  // Usar mesas robustas que incluyen las del admin
  const { tables: robustTables, loading: robustTablesLoading } = useRobustTables(barId)
  const { tables: adminTables, loading: adminTablesLoading } = useAdminTables(barId)

  useEffect(() => {
    const barParam = searchParams.get("barId")
    const tableParam = searchParams.get("tableId")

    console.log("[v0] Mesa page - URL params:", { barParam, tableParam })
    console.log("[v0] Mesa page - Admin tables:", adminTables)
    console.log("[v0] Mesa page - Robust tables:", robustTables)

    setBarId(barParam)
    setTableId(tableParam)

    // Usar datos simplificados - no depender de migración
    if (simpleTable && simpleBar && !tableLoading && !barLoading) {
      setTableNumber(simpleTable.number)
      setBarLogo(simpleBar.logoUrl || null)
      
      // Si la mesa tiene contraseña, requerir autenticación
      if (simpleTable.password) {
        setTablePassword(simpleTable.password)
        setIsPasswordRequired(true)
      } else {
        setIsAuthenticated(true)
      }
      
      setLoading(false)
    }
  }, [searchParams, simpleTable, simpleBar, tableLoading, barLoading, adminTables, robustTables])

  const handlePasswordSubmit = (inputPassword: string) => {
    if (inputPassword === tablePassword) {
      setIsAuthenticated(true)
      setPasswordError("")
    } else {
      setPasswordError("Contraseña incorrecta")
    }
  }

  const handleOrderCreated = (orderId: string, orderSummary: string) => {
    console.log("Order created:", { orderId, orderSummary })
    // Aquí podrías mostrar una notificación o actualizar el estado
  }

  console.log("[v0] Mesa page render state:", {
    barId,
    tableId,
    tableNumber,
    loading,
    isAuthenticated,
    isPasswordRequired,
    tablePassword,
    simpleTable: simpleTable ? {
      id: simpleTable.id,
      number: simpleTable.number,
      password: simpleTable.password ? "***SET***" : "NOT_SET",
      isActive: simpleTable.isActive
    } : null
  })

  if (!barId || !tableId) {
    return (
      <div
        className="min-h-screen flex items-center justify-center p-4"
        style={{
          background: "linear-gradient(135deg, var(--mt-bg), var(--mt-secondary))",
        }}
      >
        <Card
          className="rounded-2xl shadow-2xl border animate-in fade-in-0 zoom-in-95 duration-500"
          style={{
            backgroundColor: "var(--mt-surface)",
            borderColor: "var(--mt-secondary)",
          }}
        >
          <CardHeader className="text-center">
            <div className="mx-auto mb-4 h-12 w-12 rounded-full bg-red-500/20 flex items-center justify-center">
              <svg className="h-6 w-6 text-red-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={2}
                  d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-2.5L13.732 4c-.77-.833-1.964-.833-2.732 0L3.732 16.5c-.77.833.192 2.5 1.732 2.5z"
                />
              </svg>
            </div>
            <CardTitle style={{ color: "var(--mt-text)" }}>Parámetros Faltantes</CardTitle>
            <CardDescription style={{ color: "var(--mt-text)", opacity: 0.7 }}>
              Se requieren barId y tableId para acceder al chat
            </CardDescription>
          </CardHeader>
        </Card>
      </div>
    )
  }

  if (migration.isLoading) {
    return (
      <div
        className="min-h-screen flex items-center justify-center p-4"
        style={{
          background: "linear-gradient(135deg, var(--mt-bg), var(--mt-secondary))",
        }}
      >
        <Card
          className="rounded-2xl shadow-2xl border animate-in fade-in-0 zoom-in-95 duration-500"
          style={{
            backgroundColor: "var(--mt-surface)",
            borderColor: "var(--mt-secondary)",
          }}
        >
          <CardContent className="p-8">
            <div className="text-center space-y-4">
              <div
                className="mx-auto h-12 w-12 animate-spin rounded-full border-4 border-t-transparent"
                style={{ borderColor: "var(--mt-primary)" }}
              ></div>
              <div className="font-medium" style={{ color: "var(--mt-text)" }}>
                {migration.isChecking ? "Verificando configuración..." : "Actualizando sistema..."}
              </div>
              <div className="text-sm" style={{ color: "var(--mt-text)", opacity: 0.7 }}>
                {migration.isChecking ? "Comprobando versión del bar" : "Aplicando mejoras automáticas"}
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    )
  }

  if (migration.error) {
    return (
      <div
        className="min-h-screen flex items-center justify-center p-4"
        style={{
          background: "linear-gradient(135deg, var(--mt-bg), var(--mt-secondary))",
        }}
      >
        <Card
          className="rounded-2xl shadow-2xl border animate-in fade-in-0 zoom-in-95 duration-500"
          style={{
            backgroundColor: "var(--mt-surface)",
            borderColor: "var(--mt-secondary)",
          }}
        >
          <CardHeader className="text-center">
            <div className="mx-auto mb-4 h-12 w-12 rounded-full bg-red-500/20 flex items-center justify-center">
              <svg className="h-6 w-6 text-red-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={2}
                  d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-2.5L13.732 4c-.77-.833-1.964-.833-2.732 0L3.732 16.5c-.77.833.192 2.5 1.732 2.5z"
                />
              </svg>
            </div>
            <CardTitle style={{ color: "var(--mt-text)" }}>Error de Configuración</CardTitle>
            <CardDescription style={{ color: "var(--mt-text)", opacity: 0.7 }}>
              No se pudo actualizar la configuración del bar: {migration.error}
            </CardDescription>
          </CardHeader>
        </Card>
      </div>
    )
  }

  if (loading || tableLoading || barLoading || tableAuth.loading || robustTablesLoading) {
    return (
      <div
        className="min-h-screen flex items-center justify-center p-4"
        style={{
          background: "linear-gradient(135deg, var(--mt-bg), var(--mt-secondary))",
        }}
      >
        <Card
          className="rounded-2xl shadow-2xl border animate-in fade-in-0 zoom-in-95 duration-500"
          style={{
            backgroundColor: "var(--mt-surface)",
            borderColor: "var(--mt-secondary)",
          }}
        >
          <CardContent className="p-8">
            <div className="text-center space-y-4">
              <div
                className="mx-auto h-12 w-12 animate-spin rounded-full border-4 border-t-transparent"
                style={{ borderColor: "var(--mt-primary)" }}
              ></div>
              <div className="font-medium" style={{ color: "var(--mt-text)" }}>
                {tableAuth.loading ? "Autenticando..." : "Cargando información de la mesa..."}
              </div>
              <div className="text-sm" style={{ color: "var(--mt-text)", opacity: 0.7 }}>
                {tableAuth.loading ? "Conectando con la mesa" : "Conectando con el servidor"}
              </div>
              {tableAuth.error && (
                <div className="text-red-500 text-sm mt-2">{tableAuth.error}</div>
              )}
              {/* Skeleton loading animation */}
              <div className="space-y-3 mt-6">
                <div className="h-4 rounded animate-pulse" style={{ backgroundColor: "var(--mt-secondary)" }}></div>
                <div
                  className="h-4 rounded animate-pulse w-3/4 mx-auto"
                  style={{ backgroundColor: "var(--mt-secondary)" }}
                ></div>
                <div
                  className="h-4 rounded animate-pulse w-1/2 mx-auto"
                  style={{ backgroundColor: "var(--mt-secondary)" }}
                ></div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    )
  }

  if (isPasswordRequired && !isAuthenticated) {
    return (
      <div className="animate-in fade-in-0 slide-in-from-bottom-4 duration-500">
        <TablePasswordPrompt
          tableNumber={tableNumber || 1}
          onPasswordSubmit={handlePasswordSubmit}
          error={passwordError}
        />
      </div>
    )
  }

  const safeTableNumber = typeof tableNumber === "number" ? tableNumber : 1
  const safeBarId = barId || ""
  const safeTableId = tableId || ""

  console.log("[v0] About to render InterTableChatWindow with props:", {
    tableId: safeTableId,
    barId: safeBarId,
    tableNumber: safeTableNumber,
    barLogo,
  })

  return (
    <div
      className="min-h-screen"
      style={{
        background: "linear-gradient(135deg, var(--mt-bg), var(--mt-secondary))",
      }}
    >
      {barLogo && (
        <div className="flex justify-center pt-1 pb-1 animate-in slide-in-from-top-4 duration-500 delay-200">
          <img
            src={barLogo || "/placeholder.svg"}
            alt="Logo del bar"
            className="h-8 w-auto object-contain transition-transform duration-300 hover:scale-105"
          />
        </div>
      )}
      <div className="animate-in slide-in-from-bottom-4 duration-500 delay-300">
            <InterTableChatWindow tableId={safeTableId} barId={safeBarId} tableNumber={safeTableNumber} barLogo={barLogo} />
      </div>
    </div>
  )
}

export function MesaPageClient() {
  const searchParams = useSearchParams()
  const barId = searchParams.get("barId")

  return (
    <ThemeProvider barId={barId || undefined}>
      <MesaContent />
    </ThemeProvider>
  )
}
