"use client"

import { useState, useEffect } from "react"
import {
  collection,
  doc,
  addDoc,
  updateDoc,
  deleteDoc,
  query,
  orderBy,
  onSnapshot,
  increment,
} from "firebase/firestore"
import { db } from "@/src/services/firebaseConfig"
import type { Announcement, AnnouncementStats } from "@/src/types/announcement"

export function useAnnouncements(barId?: string) {
  const [announcements, setAnnouncements] = useState<Announcement[]>([])
  const [activeAnnouncements, setActiveAnnouncements] = useState<Announcement[]>([])
  const [stats, setStats] = useState<AnnouncementStats | null>(null)
  const [isLoading, setIsLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    if (!barId) {
      setIsLoading(false)
      return
    }

    const announcementsQuery = query(
      collection(db, `bars/${barId}/announcements`),
      orderBy("priority", "desc"),
      orderBy("createdAt", "desc"),
    )

    const unsubscribe = onSnapshot(
      announcementsQuery,
      (snapshot) => {
        const announcementsList = snapshot.docs.map((doc) => ({
          id: doc.id,
          ...doc.data(),
        })) as Announcement[]

        setAnnouncements(announcementsList)

        // Filter active announcements
        const now = new Date().toISOString()
        const active = announcementsList.filter(
          (announcement) => announcement.isActive && announcement.start <= now && announcement.end >= now,
        )
        setActiveAnnouncements(active)

        // Calculate stats
        calculateStats(announcementsList)
        setIsLoading(false)
        setError(null)
      },
      (err) => {
        console.error("Error loading announcements:", err)
        setError(err.message)
        setIsLoading(false)
      },
    )

    return () => unsubscribe()
  }, [barId])

  const calculateStats = (announcementsList: Announcement[]) => {
    const totalImpressions = announcementsList.reduce((sum, a) => sum + a.impressions, 0)
    const totalClicks = announcementsList.reduce((sum, a) => sum + a.clicks, 0)
    const clickThroughRate = totalImpressions > 0 ? (totalClicks / totalImpressions) * 100 : 0

    const topPerforming = [...announcementsList].sort((a, b) => b.clicks - a.clicks).slice(0, 5)

    setStats({
      totalAnnouncements: announcementsList.length,
      activeAnnouncements: activeAnnouncements.length,
      totalImpressions,
      totalClicks,
      clickThroughRate,
      topPerformingAnnouncements: topPerforming,
    })
  }

  const createAnnouncement = async (
    announcementData: Omit<Announcement, "id" | "barId" | "impressions" | "clicks" | "createdAt" | "updatedAt">,
  ) => {
    if (!barId) throw new Error("Bar ID is required")

    try {
      const newAnnouncement = {
        ...announcementData,
        barId,
        impressions: 0,
        clicks: 0,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      }

      const docRef = await addDoc(collection(db, `bars/${barId}/announcements`), newAnnouncement)
      return docRef.id
    } catch (err) {
      console.error("Error creating announcement:", err)
      throw err
    }
  }

  const updateAnnouncement = async (announcementId: string, updates: Partial<Announcement>) => {
    if (!barId) throw new Error("Bar ID is required")

    try {
      const announcementRef = doc(db, `bars/${barId}/announcements/${announcementId}`)
      await updateDoc(announcementRef, {
        ...updates,
        updatedAt: new Date().toISOString(),
      })
    } catch (err) {
      console.error("Error updating announcement:", err)
      throw err
    }
  }

  const deleteAnnouncement = async (announcementId: string) => {
    if (!barId) throw new Error("Bar ID is required")

    try {
      await deleteDoc(doc(db, `bars/${barId}/announcements/${announcementId}`))
    } catch (err) {
      console.error("Error deleting announcement:", err)
      throw err
    }
  }

  const trackImpression = async (announcementId: string) => {
    if (!barId) return

    try {
      const announcementRef = doc(db, `bars/${barId}/announcements/${announcementId}`)
      await updateDoc(announcementRef, {
        impressions: increment(1),
      })
    } catch (err) {
      console.error("Error tracking impression:", err)
    }
  }

  const trackClick = async (announcementId: string) => {
    if (!barId) return

    try {
      const announcementRef = doc(db, `bars/${barId}/announcements/${announcementId}`)
      await updateDoc(announcementRef, {
        clicks: increment(1),
      })
    } catch (err) {
      console.error("Error tracking click:", err)
    }
  }

  const toggleAnnouncementStatus = async (announcementId: string, isActive: boolean) => {
    await updateAnnouncement(announcementId, { isActive })
  }

  return {
    announcements,
    activeAnnouncements,
    stats,
    isLoading,
    error,
    createAnnouncement,
    updateAnnouncement,
    deleteAnnouncement,
    trackImpression,
    trackClick,
    toggleAnnouncementStatus,
  }
}
