"use client"

import type React from "react"

import { useState } from "react"
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Calendar } from "@/components/ui/calendar"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"
import { createReservationWithTableAssignment } from "@/lib/reservations"
import type { ReservationSiteConfig } from "@/src/types/reservation"
import { CalendarIcon, Clock, Users, Phone, Mail, MessageSquare, Loader2 } from "lucide-react"
import { format, addDays, isBefore, startOfDay, isToday, isTomorrow } from "date-fns"
import { es } from "date-fns/locale"
import { cn } from "@/lib/utils"

interface PublicReservationFormProps {
  barId: string
  barName: string
  config: ReservationSiteConfig
  onClose: () => void
  onSuccess: (reservationId: string) => void
}

export function PublicReservationForm({ barId, barName, config, onClose, onSuccess }: PublicReservationFormProps) {
  const [selectedDate, setSelectedDate] = useState<Date>()
  const [selectedTime, setSelectedTime] = useState<string>("")
  const [duration, setDuration] = useState<number>(120)
  const [partySize, setPartySize] = useState<number>(2)
  const [customerName, setCustomerName] = useState("")
  const [customerPhone, setCustomerPhone] = useState("")
  const [customerEmail, setCustomerEmail] = useState("")
  const [notes, setNotes] = useState("")
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [error, setError] = useState<string | null>(null)

  const minDate = addDays(new Date(), 0) // Today
  const maxDate = addDays(new Date(), 30) // 30 days ahead

  // Generate time slots (12:00 to 22:00, every 30 minutes)
  const timeSlots = []
  for (let hour = 12; hour <= 22; hour++) {
    for (let minute = 0; minute < 60; minute += 30) {
      const time = `${hour.toString().padStart(2, "0")}:${minute.toString().padStart(2, "0")}`
      timeSlots.push(time)
    }
  }

  const getDateLabel = (date: Date) => {
    if (isToday(date)) return "Hoy"
    if (isTomorrow(date)) return "Mañana"
    return format(date, "EEEE d 'de' MMMM", { locale: es })
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()

    if (!selectedDate || !selectedTime || !customerName || !customerPhone) {
      setError("Por favor completa todos los campos requeridos")
      return
    }

    // Validar formato de teléfono básico
    if (customerPhone.length < 9) {
      setError("Por favor introduce un número de teléfono válido")
      return
    }

    // Validar email si se proporciona
    if (customerEmail && !customerEmail.includes("@")) {
      setError("Por favor introduce un email válido")
      return
    }

    setIsSubmitting(true)
    setError(null)

    try {
      // Crear fecha y hora combinadas
      const [hours, minutes] = selectedTime.split(":").map(Number)
      const startAt = new Date(selectedDate)
      startAt.setHours(hours, minutes, 0, 0)

      const result = await createReservationWithTableAssignment(barId, {
        startAt,
        durationMins: duration,
        partySize,
        customerName,
        customerPhone,
        customerEmail: customerEmail || undefined,
        notes: notes || undefined,
        source: "public",
      })

      onSuccess(result.reservationId)
    } catch (err) {
      setError(err instanceof Error ? err.message : "Error al crear la reserva. Por favor intenta de nuevo.")
    } finally {
      setIsSubmitting(false)
    }
  }

  return (
    <Dialog open={true} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 text-xl">
            <CalendarIcon className="w-6 h-6" style={{ color: config.colorPrimary }} />
            Reservar en {barName}
          </DialogTitle>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-6">
          {/* Date Selection */}
          <div className="space-y-3">
            <Label className="text-base font-semibold">¿Cuándo quieres venir? *</Label>
            <Popover>
              <PopoverTrigger asChild>
                <Button
                  variant="outline"
                  className={cn(
                    "w-full justify-start text-left font-normal h-12 text-base",
                    !selectedDate && "text-muted-foreground",
                  )}
                >
                  <CalendarIcon className="mr-3 h-5 w-5" />
                  {selectedDate ? getDateLabel(selectedDate) : "Seleccionar fecha"}
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-auto p-0">
                <Calendar
                  mode="single"
                  selected={selectedDate}
                  onSelect={setSelectedDate}
                  disabled={(date) => isBefore(date, startOfDay(minDate)) || isBefore(maxDate, date)}
                  initialFocus
                />
              </PopoverContent>
            </Popover>
          </div>

          {/* Time and Party Size */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-3">
              <Label className="text-base font-semibold">¿A qué hora? *</Label>
              <Select value={selectedTime} onValueChange={setSelectedTime}>
                <SelectTrigger className="h-12 text-base">
                  <SelectValue placeholder="Seleccionar hora" />
                </SelectTrigger>
                <SelectContent>
                  {timeSlots.map((time) => (
                    <SelectItem key={time} value={time}>
                      <div className="flex items-center gap-2">
                        <Clock className="w-4 h-4" />
                        {time}
                      </div>
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-3">
              <Label className="text-base font-semibold">¿Cuántas personas? *</Label>
              <Select value={partySize.toString()} onValueChange={(value) => setPartySize(Number(value))}>
                <SelectTrigger className="h-12 text-base">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {Array.from({ length: 12 }, (_, i) => i + 1).map((size) => (
                    <SelectItem key={size} value={size.toString()}>
                      <div className="flex items-center gap-2">
                        <Users className="w-4 h-4" />
                        {size} {size === 1 ? "persona" : "personas"}
                      </div>
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          {/* Duration */}
          <div className="space-y-3">
            <Label className="text-base font-semibold">Duración estimada</Label>
            <Select value={duration.toString()} onValueChange={(value) => setDuration(Number(value))}>
              <SelectTrigger className="h-12 text-base">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="60">1 hora</SelectItem>
                <SelectItem value="90">1.5 horas</SelectItem>
                <SelectItem value="120">2 horas</SelectItem>
                <SelectItem value="150">2.5 horas</SelectItem>
                <SelectItem value="180">3 horas</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {/* Customer Information */}
          <div className="space-y-4">
            <h3 className="text-lg font-semibold">Tus Datos de Contacto</h3>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="name" className="font-medium">
                  Nombre completo *
                </Label>
                <Input
                  id="name"
                  value={customerName}
                  onChange={(e) => setCustomerName(e.target.value)}
                  placeholder="Tu nombre"
                  className="h-12 text-base"
                  required
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="phone" className="font-medium">
                  Teléfono *
                </Label>
                <div className="relative">
                  <Phone className="absolute left-3 top-4 h-4 w-4 text-muted-foreground" />
                  <Input
                    id="phone"
                    type="tel"
                    value={customerPhone}
                    onChange={(e) => setCustomerPhone(e.target.value)}
                    placeholder="600 000 000"
                    className="pl-10 h-12 text-base"
                    required
                  />
                </div>
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="email" className="font-medium">
                Email (opcional)
              </Label>
              <div className="relative">
                <Mail className="absolute left-3 top-4 h-4 w-4 text-muted-foreground" />
                <Input
                  id="email"
                  type="email"
                  value={customerEmail}
                  onChange={(e) => setCustomerEmail(e.target.value)}
                  placeholder="tu@email.com"
                  className="pl-10 h-12 text-base"
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="notes" className="font-medium">
                Comentarios especiales (opcional)
              </Label>
              <div className="relative">
                <MessageSquare className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                <Textarea
                  id="notes"
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  placeholder="Alergias, celebraciones, preferencias..."
                  className="pl-10 min-h-[80px] text-base"
                />
              </div>
            </div>
          </div>

          {error && (
            <div className="p-4 bg-destructive/10 border border-destructive/20 rounded-lg text-destructive text-sm">
              {error}
            </div>
          )}

          {/* Submit Buttons */}
          <div className="flex gap-3 pt-4">
            <Button
              type="button"
              variant="outline"
              onClick={onClose}
              className="flex-1 h-12 text-base bg-transparent"
              disabled={isSubmitting}
            >
              Cancelar
            </Button>
            <Button
              type="submit"
              disabled={isSubmitting || !selectedDate || !selectedTime || !customerName || !customerPhone}
              className="flex-1 h-12 text-base"
              style={{ backgroundColor: config.colorPrimary }}
            >
              {isSubmitting ? (
                <>
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  Creando Reserva...
                </>
              ) : (
                "Confirmar Reserva"
              )}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  )
}
