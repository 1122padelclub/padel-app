"use client"

import { useState, useEffect } from "react"
import { doc, getDoc, setDoc, onSnapshot } from "firebase/firestore"
import { db } from "@/src/services/firebaseExtras"
import type { ReservationConfig } from "@/src/types"

const DEFAULT_CONFIG: Omit<ReservationConfig, "barId" | "createdAt" | "updatedAt"> = {
  openingTime: "09:00",
  closingTime: "23:00",
  slotDuration: 30,
  maxPartySize: 8,
  minPartySize: 1,
  advanceBookingDays: 30,
  advanceBookingHours: 2,
  isActive: true,
  specialHours: {},
  reservationDurationMinutes: 120 // 2 horas por defecto
}

export function useReservationConfig(barId: string) {
  const [config, setConfig] = useState<ReservationConfig | null>(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    if (!barId) {
      setLoading(false)
      return
    }

    console.log("⚙️ Cargando configuración de reservas para barId:", barId)
    setLoading(true)

    const configRef = doc(db, "bars", barId, "reservationConfig", "config")

    const unsubscribe = onSnapshot(configRef, (snapshot) => {
      if (snapshot.exists()) {
        const data = snapshot.data()
        setConfig({
          barId,
          ...data,
          createdAt: data.createdAt?.toDate() || new Date(),
          updatedAt: data.updatedAt?.toDate() || new Date(),
        } as ReservationConfig)
      } else {
        // Crear configuración por defecto si no existe
        const defaultConfig: ReservationConfig = {
          barId,
          ...DEFAULT_CONFIG,
          createdAt: new Date(),
          updatedAt: new Date(),
        }
        setConfig(defaultConfig)
      }
      
      setLoading(false)
      setError(null)
    }, (err) => {
      console.error("❌ Error cargando configuración de reservas:", err)
      setError(err.message || "Error desconocido al cargar configuración")
      setLoading(false)
    })

    return () => unsubscribe()
  }, [barId])

  const updateConfig = async (updates: Partial<ReservationConfig>) => {
    try {
      const configRef = doc(db, "bars", barId, "reservationConfig", "config")
      await setDoc(configRef, {
        ...config,
        ...updates,
        updatedAt: new Date(),
      }, { merge: true })
    } catch (err: any) {
      console.error("❌ Error actualizando configuración de reservas:", err)
      throw new Error(err.message || "Error desconocido al actualizar configuración")
    }
  }

  const generateTimeSlots = (date: Date) => {
    if (!config) return []

    const slots: string[] = []
    const targetDate = new Date(date)
    const dayOfWeek = targetDate.getDay().toString()
    
    // Usar horarios especiales si existen para este día
    const specialHours = config.specialHours?.[dayOfWeek]
    const openingTime = specialHours?.openingTime || config.openingTime
    const closingTime = specialHours?.closingTime || config.closingTime

    const [openHour, openMinute] = openingTime.split(':').map(Number)
    const [closeHour, closeMinute] = closingTime.split(':').map(Number)

    const startTime = new Date(targetDate)
    startTime.setHours(openHour, openMinute, 0, 0)

    const endTime = new Date(targetDate)
    endTime.setHours(closeHour, closeMinute, 0, 0)

    const currentTime = new Date()
    const minAdvanceTime = new Date(currentTime.getTime() + (config.advanceBookingHours * 60 * 60 * 1000))

    let currentSlot = new Date(startTime)
    while (currentSlot < endTime) {
      // Solo incluir slots que estén en el futuro y cumplan con la anticipación mínima
      if (currentSlot >= minAdvanceTime) {
        const timeString = currentSlot.toTimeString().slice(0, 5)
        slots.push(timeString)
      }
      
      currentSlot.setMinutes(currentSlot.getMinutes() + config.slotDuration)
    }

    return slots
  }

  const isDateAvailable = (date: Date) => {
    if (!config) return false

    const today = new Date()
    today.setHours(0, 0, 0, 0)
    
    const targetDate = new Date(date)
    targetDate.setHours(0, 0, 0, 0)

    const maxAdvanceDate = new Date(today)
    maxAdvanceDate.setDate(maxAdvanceDate.getDate() + config.advanceBookingDays)

    return targetDate >= today && targetDate <= maxAdvanceDate
  }

  return {
    config,
    loading,
    error,
    updateConfig,
    generateTimeSlots,
    isDateAvailable,
  }
}
