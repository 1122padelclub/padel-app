"use client"

import type React from "react"

import { useState } from "react"
import { collection, addDoc, updateDoc, doc, deleteDoc } from "firebase/firestore"
import { db } from "@/src/services/firebaseExtras"
import { useMenu } from "@/src/hooks/useMenu"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Badge } from "@/components/ui/badge"
import { Switch } from "@/components/ui/switch"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { ImageUpload } from "@/src/components/ImageUpload"
import { Trash2, Tag } from "lucide-react"

interface AdminMenuListProps {
  barId: string
}

export function AdminMenuList({ barId }: AdminMenuListProps) {
  const { categories, items, loading, getItemsByCategory, refetch } = useMenu(barId)
  const [isCreateItemOpen, setIsCreateItemOpen] = useState(false)
  const [isCreateCategoryOpen, setIsCreateCategoryOpen] = useState(false)
  const [isCreatingItem, setIsCreatingItem] = useState(false)
  const [isCreatingCategory, setIsCreatingCategory] = useState(false)

  const [isEditItemOpen, setIsEditItemOpen] = useState(false)
  const [editingItem, setEditingItem] = useState<any>(null)
  const [isUpdatingItem, setIsUpdatingItem] = useState(false)

  const [newItemName, setNewItemName] = useState("")
  const [newItemDescription, setNewItemDescription] = useState("")
  const [newItemPrice, setNewItemPrice] = useState("")
  const [newItemCategory, setNewItemCategory] = useState("")
  const [newItemImage, setNewItemImage] = useState("")
  const [newItemPromotion, setNewItemPromotion] = useState("")
  const [newItemPromotionPrice, setNewItemPromotionPrice] = useState("")

  const [newCategoryName, setNewCategoryName] = useState("")

  const handleEditItem = (item: any) => {
    setEditingItem(item)
    setNewItemName(item.name)
    setNewItemDescription(item.description || "")
    setNewItemPrice(item.price.toString())
    setNewItemCategory(item.categoryId)
    setNewItemImage(item.imageUrl || "")
    setNewItemPromotion(item.promotion || "")
    setNewItemPromotionPrice(item.promotionPrice?.toString() || "")
    setIsEditItemOpen(true)
  }

  const handleUpdateItem = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!editingItem) return

    setIsUpdatingItem(true)
    try {
      const itemRef = doc(db, "bars", barId, "menuItems", editingItem.id)
      const updateData: any = {
        name: newItemName.trim(),
        description: newItemDescription.trim() || null,
        price: Number.parseFloat(newItemPrice),
        categoryId: newItemCategory,
        imageUrl: newItemImage || null,
        updatedAt: new Date(),
      }

      if (newItemPromotion.trim()) {
        updateData.promotion = newItemPromotion.trim()
        updateData.promotionPrice = newItemPromotionPrice ? Number.parseFloat(newItemPromotionPrice) : null
      } else {
        updateData.promotion = null
        updateData.promotionPrice = null
      }

      await updateDoc(itemRef, updateData)

      console.log("[v0] Item actualizado exitosamente")
      setIsEditItemOpen(false)
      setEditingItem(null)
      resetForm()
      refetch()
    } catch (error) {
      console.error("[v0] Error updating item:", error)
      alert("Error al actualizar el item. Por favor intenta de nuevo.")
    } finally {
      setIsUpdatingItem(false)
    }
  }

  const handleDeleteItem = async (itemId: string, itemName: string) => {
    if (!confirm(`¿Estás seguro de que quieres eliminar "${itemName}"?`)) {
      return
    }

    try {
      const itemRef = doc(db, "bars", barId, "menuItems", itemId)
      await deleteDoc(itemRef)
      console.log("[v0] Item eliminado exitosamente")
      refetch()
    } catch (error) {
      console.error("[v0] Error deleting item:", error)
      alert("Error al eliminar el item. Por favor intenta de nuevo.")
    }
  }

  const resetForm = () => {
    setNewItemName("")
    setNewItemDescription("")
    setNewItemPrice("")
    setNewItemCategory("")
    setNewItemImage("")
    setNewItemPromotion("")
    setNewItemPromotionPrice("")
  }

  const handleCreateItem = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!newItemCategory) {
      alert("Por favor selecciona una categoría")
      return
    }

    setIsCreatingItem(true)
    try {
      const itemsRef = collection(db, "bars", barId, "menuItems")
      const itemData: any = {
        barId,
        categoryId: newItemCategory,
        name: newItemName.trim(),
        description: newItemDescription.trim() || null,
        price: Number.parseFloat(newItemPrice),
        isAvailable: true,
        imageUrl: newItemImage || null,
        createdAt: new Date(),
      }

      if (newItemPromotion.trim()) {
        itemData.promotion = newItemPromotion.trim()
        itemData.promotionPrice = newItemPromotionPrice ? Number.parseFloat(newItemPromotionPrice) : null
      }

      await addDoc(itemsRef, itemData)

      console.log("[v0] Item creado exitosamente")
      setIsCreateItemOpen(false)
      resetForm()
      refetch()
    } catch (error) {
      console.error("[v0] Error creating item:", error)
      alert("Error al crear el item. Por favor intenta de nuevo.")
    } finally {
      setIsCreatingItem(false)
    }
  }

  const handleCreateCategory = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsCreatingCategory(true)
    try {
      const categoriesRef = collection(db, "bars", barId, "menuCategories")
      await addDoc(categoriesRef, {
        barId,
        name: newCategoryName.trim(),
        order: categories.length,
        createdAt: new Date(),
      })

      console.log("[v0] Categoría creada exitosamente")
      setIsCreateCategoryOpen(false)
      setNewCategoryName("")
      refetch()
    } catch (error) {
      console.error("[v0] Error creating category:", error)
      alert("Error al crear la categoría. Por favor intenta de nuevo.")
    } finally {
      setIsCreatingCategory(false)
    }
  }

  const handleToggleAvailability = async (itemId: string, currentAvailability: boolean) => {
    try {
      const itemRef = doc(db, "bars", barId, "menuItems", itemId)
      await updateDoc(itemRef, {
        isAvailable: !currentAvailability,
        updatedAt: new Date(),
      })
      console.log("[v0] Disponibilidad actualizada")
      refetch()
    } catch (error) {
      console.error("[v0] Error updating availability:", error)
      alert("Error al actualizar la disponibilidad")
    }
  }

  if (loading) {
    return (
      <Card className="rounded-2xl">
        <CardContent className="flex items-center justify-center h-32">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
        </CardContent>
      </Card>
    )
  }

  return (
    <div className="space-y-6">
      <Card className="rounded-2xl">
        <CardHeader>
          <div className="flex justify-between items-center">
            <div>
              <CardTitle className="font-serif">Gestión de Menú</CardTitle>
              <CardDescription>Administrar categorías e items del menú</CardDescription>
            </div>
            <div className="flex gap-2">
              <Dialog open={isCreateCategoryOpen} onOpenChange={setIsCreateCategoryOpen}>
                <DialogTrigger asChild>
                  <Button variant="outline" className="rounded-xl bg-transparent">
                    Nueva Categoría
                  </Button>
                </DialogTrigger>
                <DialogContent className="rounded-2xl">
                  <DialogHeader>
                    <DialogTitle>Crear Nueva Categoría</DialogTitle>
                    <DialogDescription>Agregar una nueva categoría al menú</DialogDescription>
                  </DialogHeader>
                  <form onSubmit={handleCreateCategory} className="space-y-4">
                    <div className="space-y-2">
                      <Label htmlFor="categoryName">Nombre de la Categoría</Label>
                      <Input
                        id="categoryName"
                        value={newCategoryName}
                        onChange={(e) => setNewCategoryName(e.target.value)}
                        required
                        className="rounded-xl"
                        disabled={isCreatingCategory}
                      />
                    </div>
                    <Button type="submit" className="w-full rounded-xl" disabled={isCreatingCategory}>
                      {isCreatingCategory ? "Creando..." : "Crear Categoría"}
                    </Button>
                  </form>
                </DialogContent>
              </Dialog>

              <Dialog open={isCreateItemOpen} onOpenChange={setIsCreateItemOpen}>
                <DialogTrigger asChild>
                  <Button className="rounded-xl">Nuevo Item</Button>
                </DialogTrigger>
                <DialogContent className="rounded-2xl max-w-lg max-h-[90vh] overflow-y-auto">
                  <DialogHeader>
                    <DialogTitle>Crear Nuevo Item</DialogTitle>
                    <DialogDescription>Agregar un nuevo item al menú</DialogDescription>
                  </DialogHeader>
                  <form onSubmit={handleCreateItem} className="space-y-4">
                    <ImageUpload
                      label="Imagen del Item"
                      description="Sube una imagen para el item del menú"
                      value={newItemImage}
                      onChange={setNewItemImage}
                    />

                    <div className="space-y-2">
                      <Label htmlFor="itemName">Nombre del Item</Label>
                      <Input
                        id="itemName"
                        value={newItemName}
                        onChange={(e) => setNewItemName(e.target.value)}
                        required
                        className="rounded-xl"
                        disabled={isCreatingItem}
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="itemDescription">Descripción</Label>
                      <Textarea
                        id="itemDescription"
                        value={newItemDescription}
                        onChange={(e) => setNewItemDescription(e.target.value)}
                        className="rounded-xl resize-none"
                        rows={3}
                        disabled={isCreatingItem}
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="itemPrice">Precio</Label>
                      <Input
                        id="itemPrice"
                        type="number"
                        step="0.01"
                        min="0"
                        value={newItemPrice}
                        onChange={(e) => setNewItemPrice(e.target.value)}
                        required
                        className="rounded-xl"
                        disabled={isCreatingItem}
                      />
                    </div>
                    <div className="space-y-4 p-4 bg-muted/50 rounded-xl">
                      <div className="flex items-center gap-2">
                        <Tag className="h-4 w-4" />
                        <Label className="text-sm font-medium">Promoción (Opcional)</Label>
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="itemPromotion">Descripción de la Promoción</Label>
                        <Input
                          id="itemPromotion"
                          value={newItemPromotion}
                          onChange={(e) => setNewItemPromotion(e.target.value)}
                          placeholder="ej: 2x1, 50% descuento"
                          className="rounded-xl"
                          disabled={isCreatingItem}
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="itemPromotionPrice">Precio con Promoción</Label>
                        <Input
                          id="itemPromotionPrice"
                          type="number"
                          step="0.01"
                          min="0"
                          value={newItemPromotionPrice}
                          onChange={(e) => setNewItemPromotionPrice(e.target.value)}
                          placeholder="Precio promocional"
                          className="rounded-xl"
                          disabled={isCreatingItem}
                        />
                      </div>
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="itemCategory">Categoría</Label>
                      <Select value={newItemCategory} onValueChange={setNewItemCategory} disabled={isCreatingItem}>
                        <SelectTrigger className="rounded-xl">
                          <SelectValue placeholder="Selecciona una categoría" />
                        </SelectTrigger>
                        <SelectContent>
                          {categories.map((category) => (
                            <SelectItem key={category.id} value={category.id}>
                              {category.name}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      {categories.length === 0 && (
                        <p className="text-sm text-muted-foreground">Primero debes crear una categoría</p>
                      )}
                    </div>
                    <Button
                      type="submit"
                      className="w-full rounded-xl"
                      disabled={isCreatingItem || categories.length === 0}
                    >
                      {isCreatingItem ? "Creando..." : "Crear Item"}
                    </Button>
                  </form>
                </DialogContent>
              </Dialog>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <Dialog open={isEditItemOpen} onOpenChange={setIsEditItemOpen}>
            <DialogContent className="rounded-2xl max-w-lg max-h-[90vh] overflow-y-auto">
              <DialogHeader>
                <DialogTitle>Editar Item</DialogTitle>
                <DialogDescription>Modificar la información del item</DialogDescription>
              </DialogHeader>
              <form onSubmit={handleUpdateItem} className="space-y-4">
                <ImageUpload
                  label="Imagen del Item"
                  description="Sube una imagen para el item del menú"
                  value={newItemImage}
                  onChange={setNewItemImage}
                />

                <div className="space-y-2">
                  <Label htmlFor="editItemName">Nombre del Item</Label>
                  <Input
                    id="editItemName"
                    value={newItemName}
                    onChange={(e) => setNewItemName(e.target.value)}
                    required
                    className="rounded-xl"
                    disabled={isUpdatingItem}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="editItemDescription">Descripción</Label>
                  <Textarea
                    id="editItemDescription"
                    value={newItemDescription}
                    onChange={(e) => setNewItemDescription(e.target.value)}
                    className="rounded-xl resize-none"
                    rows={3}
                    disabled={isUpdatingItem}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="editItemPrice">Precio</Label>
                  <Input
                    id="editItemPrice"
                    type="number"
                    step="0.01"
                    min="0"
                    value={newItemPrice}
                    onChange={(e) => setNewItemPrice(e.target.value)}
                    required
                    className="rounded-xl"
                    disabled={isUpdatingItem}
                  />
                </div>
                <div className="space-y-4 p-4 bg-muted/50 rounded-xl">
                  <div className="flex items-center gap-2">
                    <Tag className="h-4 w-4" />
                    <Label className="text-sm font-medium">Promoción (Opcional)</Label>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="editItemPromotion">Descripción de la Promoción</Label>
                    <Input
                      id="editItemPromotion"
                      value={newItemPromotion}
                      onChange={(e) => setNewItemPromotion(e.target.value)}
                      placeholder="ej: 2x1, 50% descuento"
                      className="rounded-xl"
                      disabled={isUpdatingItem}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="editItemPromotionPrice">Precio con Promoción</Label>
                    <Input
                      id="editItemPromotionPrice"
                      type="number"
                      step="0.01"
                      min="0"
                      value={newItemPromotionPrice}
                      onChange={(e) => setNewItemPromotionPrice(e.target.value)}
                      placeholder="Precio promocional"
                      className="rounded-xl"
                      disabled={isUpdatingItem}
                    />
                  </div>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="editItemCategory">Categoría</Label>
                  <Select value={newItemCategory} onValueChange={setNewItemCategory} disabled={isUpdatingItem}>
                    <SelectTrigger className="rounded-xl">
                      <SelectValue placeholder="Selecciona una categoría" />
                    </SelectTrigger>
                    <SelectContent>
                      {categories.map((category) => (
                        <SelectItem key={category.id} value={category.id}>
                          {category.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <Button type="submit" className="w-full rounded-xl" disabled={isUpdatingItem}>
                  {isUpdatingItem ? "Actualizando..." : "Actualizar Item"}
                </Button>
              </form>
            </DialogContent>
          </Dialog>

          <Tabs defaultValue={categories.length > 0 ? categories[0]?.id : "empty"} className="w-full">
            <TabsList className="grid w-full grid-cols-3 rounded-xl">
              {categories.slice(0, 3).map((category) => (
                <TabsTrigger key={category.id} value={category.id} className="rounded-lg">
                  {category.name}
                </TabsTrigger>
              ))}
            </TabsList>

            {categories.map((category) => (
              <TabsContent key={category.id} value={category.id} className="mt-4">
                <div className="space-y-4">
                  {getItemsByCategory(category.id).map((item) => (
                    <Card key={item.id} className="rounded-xl">
                      <CardHeader className="pb-3">
                        <div className="flex justify-between items-start gap-4">
                          {item.imageUrl && (
                            <img
                              src={item.imageUrl || "/placeholder.svg"}
                              alt={item.name}
                              className="w-16 h-16 object-cover rounded-lg flex-shrink-0"
                            />
                          )}
                          <div className="flex-1">
                            <CardTitle className="text-lg">{item.name}</CardTitle>
                            {item.description && <CardDescription>{item.description}</CardDescription>}
                            {item.promotion && (
                              <div className="mt-2">
                                <Badge
                                  variant="outline"
                                  className="rounded-lg bg-orange-100 text-orange-800 border-orange-200"
                                >
                                  <Tag className="h-3 w-3 mr-1" />
                                  {item.promotion}
                                </Badge>
                              </div>
                            )}
                          </div>
                          <div className="flex items-center gap-2">
                            <div className="flex flex-col items-end">
                              {item.promotionPrice ? (
                                <>
                                  <Badge variant="secondary" className="rounded-lg line-through text-xs">
                                    ${item.price.toFixed(2)}
                                  </Badge>
                                  <Badge variant="default" className="rounded-lg bg-green-600">
                                    ${item.promotionPrice.toFixed(2)}
                                  </Badge>
                                </>
                              ) : (
                                <Badge variant="secondary" className="rounded-lg">
                                  ${item.price.toFixed(2)}
                                </Badge>
                              )}
                            </div>
                            <Badge variant={item.isAvailable ? "default" : "secondary"} className="rounded-lg">
                              {item.isAvailable ? "Disponible" : "No disponible"}
                            </Badge>
                            <div className="flex gap-1">
                              <Button
                                variant="outline"
                                size="sm"
                                onClick={() => handleEditItem(item)}
                                className="rounded-lg p-2"
                              >
                                <Tag className="h-3 w-3" />
                              </Button>
                              <Button
                                variant="outline"
                                size="sm"
                                onClick={() => handleDeleteItem(item.id, item.name)}
                                className="rounded-lg p-2 text-red-600 hover:text-red-700 hover:bg-red-50"
                              >
                                <Trash2 className="h-3 w-3" />
                              </Button>
                            </div>
                          </div>
                        </div>
                      </CardHeader>
                      <CardContent>
                        <div className="flex items-center justify-between">
                          <Label htmlFor={`available-${item.id}`} className="text-sm">
                            Disponible
                          </Label>
                          <Switch
                            id={`available-${item.id}`}
                            checked={item.isAvailable}
                            onCheckedChange={() => handleToggleAvailability(item.id, item.isAvailable)}
                          />
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                  {getItemsByCategory(category.id).length === 0 && (
                    <div className="text-center text-muted-foreground py-8">
                      <p>No hay items en esta categoría</p>
                    </div>
                  )}
                </div>
              </TabsContent>
            ))}

            <TabsContent value="empty" className="mt-4">
              <div className="text-center text-muted-foreground py-8">
                <p>No hay categorías creadas. Crea una categoría para empezar a agregar items al menú.</p>
              </div>
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>
    </div>
  )
}
