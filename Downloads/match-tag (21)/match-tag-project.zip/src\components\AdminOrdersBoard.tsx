"use client"

import { useAdminOrders } from "@/src/hooks/useAdminOrders"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import type { Order } from "@/src/types"

interface AdminOrdersBoardProps {
  barId: string
}

const formatDateTime = (date: Date | any) => {
  const d = date instanceof Date ? date : new Date(date)
  const time = d.toLocaleTimeString("es-ES", {
    hour: "2-digit",
    minute: "2-digit",
    hour12: false,
  })
  const dateStr = d.toLocaleDateString("es-ES", {
    day: "2-digit",
    month: "2-digit",
  })
  return `${time} - ${dateStr}`
}

const ORDER_STATUS_CONFIG = {
  pending: { label: "Pendiente", variant: "secondary" as const, color: "bg-yellow-500" },
  confirmed: { label: "Confirmado", variant: "default" as const, color: "bg-blue-500" },
  preparing: { label: "Preparando", variant: "default" as const, color: "bg-orange-500" },
  ready: { label: "Listo", variant: "default" as const, color: "bg-green-500" },
  delivered: { label: "Entregado", variant: "outline" as const, color: "bg-gray-500" },
  cancelled: { label: "Cancelado", variant: "destructive" as const, color: "bg-red-500" },
}

const STATUS_TRANSITIONS = {
  pending: ["confirmed", "cancelled"],
  confirmed: ["preparing", "cancelled"],
  preparing: ["ready", "cancelled"],
  ready: ["delivered"],
  delivered: [],
  cancelled: [],
}

export function AdminOrdersBoard({ barId }: AdminOrdersBoardProps) {
  const { orders, loading, updateOrderStatus } = useAdminOrders(barId)

  const handleStatusChange = async (orderId: string, newStatus: Order["status"]) => {
    await updateOrderStatus(orderId, newStatus)
  }

  if (loading) {
    return (
      <Card className="rounded-2xl">
        <CardContent className="flex items-center justify-center h-32">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
        </CardContent>
      </Card>
    )
  }

  const activeOrders = orders.filter((order) => !["delivered", "cancelled"].includes(order.status))

  return (
    <Card className="rounded-2xl">
      <CardHeader>
        <CardTitle className="font-serif">Panel de Pedidos</CardTitle>
        <CardDescription>Gestionar estado de pedidos en tiempo real</CardDescription>
      </CardHeader>
      <CardContent>
        {activeOrders.length === 0 ? (
          <div className="text-center text-muted-foreground py-8">
            <p>No hay pedidos activos</p>
          </div>
        ) : (
          <div className="space-y-4">
            {activeOrders.map((order) => (
              <Card key={order.id} className="rounded-xl">
                <CardHeader className="pb-3">
                  <div className="flex justify-between items-start">
                    <div>
                      {order.senderTableNumber ? (
                        <>
                          Mesa {order.senderTableNumber} → Mesa {order.tableNumber}
                        </>
                      ) : (
                        <>Mesa {order.tableNumber}</>
                      )}
                      <CardDescription>
                        {formatDateTime(order.createdAt)}
                        {order.senderTableNumber && (
                          <span className="ml-2 text-xs bg-blue-100 text-blue-800 px-2 py-1 rounded-full">
                            Pedido enviado
                          </span>
                        )}
                      </CardDescription>
                    </div>
                    <div className="flex items-center gap-2">
                      <Badge variant={ORDER_STATUS_CONFIG[order.status].variant} className="rounded-lg">
                        {ORDER_STATUS_CONFIG[order.status].label}
                      </Badge>
                      <Badge variant="outline" className="rounded-lg">
                        ${(order.total || 0).toFixed(2)}
                      </Badge>
                    </div>
                  </div>
                </CardHeader>
                <CardContent className="space-y-4">
                  {(order.customerName || order.accountType) && (
                    <div className="bg-slate-50 border border-slate-200 rounded-lg p-3">
                      <div className="flex items-center justify-between">
                        <div>
                          <p className="text-sm font-medium text-slate-900">👤 {order.customerName || "Cliente"}</p>
                          {order.customerPhone && <p className="text-xs text-slate-600">📞 {order.customerPhone}</p>}
                        </div>
                        <div className="flex items-center gap-2">
                          {order.accountType && (
                            <Badge
                              variant={order.accountType === "individual" ? "default" : "secondary"}
                              className={`rounded-lg text-xs ${
                                order.accountType === "individual"
                                  ? "bg-green-100 text-green-800 border-green-200"
                                  : "bg-blue-100 text-blue-800 border-blue-200"
                              }`}
                            >
                              {order.accountType === "individual" ? "🧾 Cuenta Individual" : "👥 Cuenta Compartida"}
                            </Badge>
                          )}
                        </div>
                      </div>
                    </div>
                  )}

                  <div className="space-y-3">
                    {order.items.map((item, index) => (
                      <div key={index} className="space-y-2">
                        <div className="flex justify-between items-center text-sm">
                          <span>
                            {item.quantity}x {item.name}
                          </span>
                          <span>${((item.price || 0) * (item.quantity || 0)).toFixed(2)}</span>
                        </div>
                        {(item.specifications || item.notes) && (
                          <div className="ml-4 p-2 bg-amber-50 border-l-4 border-amber-200 rounded-r-lg">
                            <p className="text-xs font-medium text-amber-800 mb-1">📝 Especificaciones:</p>
                            <p className="text-xs text-amber-700">{item.specifications || item.notes}</p>
                          </div>
                        )}
                      </div>
                    ))}
                  </div>

                  <div className="flex gap-2 flex-wrap">
                    {STATUS_TRANSITIONS[order.status].map((nextStatus) => (
                      <Button
                        key={nextStatus}
                        size="sm"
                        variant={nextStatus === "cancelled" ? "destructive" : "default"}
                        onClick={() => handleStatusChange(order.id, nextStatus as Order["status"])}
                        className="rounded-lg"
                      >
                        {ORDER_STATUS_CONFIG[nextStatus as Order["status"]].label}
                      </Button>
                    ))}
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  )
}
