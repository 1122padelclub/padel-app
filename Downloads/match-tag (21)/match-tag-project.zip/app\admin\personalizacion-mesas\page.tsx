"use client"

import { useState, useEffect, Suspense } from "react"
import { useSearchParams } from "next/navigation"
import { TableCustomizationEditor } from "@/src/components/TableCustomizationEditor"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { ArrowLeft, Save, Eye } from "lucide-react"
import Link from "next/link"

function PersonalizacionMesasContent() {
  const searchParams = useSearchParams()
  const barId = searchParams.get("barId")
  const [previewMode, setPreviewMode] = useState(false)

  console.log("Personalización - barId recibido:", barId)

  if (!barId) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Card className="w-full max-w-md">
          <CardHeader>
            <CardTitle className="text-center">Error</CardTitle>
          </CardHeader>
          <CardContent className="text-center">
            <p className="text-red-600 mb-4">No se proporcionó barId</p>
            <p className="text-sm text-gray-600 mb-4">
              URL actual: {typeof window !== 'undefined' ? window.location.href : 'N/A'}
            </p>
            <Link href="/admin">
              <Button>
                <ArrowLeft className="h-4 w-4 mr-2" />
                Volver al Admin
              </Button>
            </Link>
          </CardContent>
        </Card>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="container mx-auto px-4 py-8">
        <div className="mb-6">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-4">
              <Link href={`/admin?barId=${barId}`}>
                <Button variant="outline" size="sm">
                  <ArrowLeft className="h-4 w-4 mr-2" />
                  Volver
                </Button>
              </Link>
              <h1 className="text-3xl font-bold">Personalización de Mesas</h1>
            </div>
            <div className="flex gap-2">
              <Button
                variant="outline"
                onClick={() => setPreviewMode(!previewMode)}
              >
                <Eye className="h-4 w-4 mr-2" />
                {previewMode ? "Editar" : "Vista Previa"}
              </Button>
            </div>
          </div>
          <p className="text-gray-600">
            Personaliza la apariencia de las mesas de tu bar. Los cambios se aplicarán inmediatamente.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2">
            <TableCustomizationEditor 
              barId={barId}
              onSave={(customization) => {
                console.log("Personalización guardada:", customization)
                // Aquí podrías mostrar una notificación de éxito
              }}
            />
          </div>

          <div className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Información</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <h4 className="font-medium mb-2">Bar ID</h4>
                  <p className="text-sm text-gray-600 font-mono">{barId}</p>
                </div>
                <div>
                  <h4 className="font-medium mb-2">Estado</h4>
                  <p className="text-sm text-green-600">Activo</p>
                </div>
                <div>
                  <h4 className="font-medium mb-2">Última actualización</h4>
                  <p className="text-sm text-gray-600">
                    {new Date().toLocaleString()}
                  </p>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Vista Previa</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-center">
                  <p className="text-sm text-gray-600 mb-4">
                    Escanea el código QR de una mesa para ver la personalización en acción
                  </p>
                  <div className="bg-gray-100 p-4 rounded-lg">
                    <div className="text-4xl mb-2">📱</div>
                    <p className="text-sm">Código QR de Mesa</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Ayuda</CardTitle>
              </CardHeader>
              <CardContent className="space-y-2">
                <div className="text-sm">
                  <h4 className="font-medium mb-1">Colores</h4>
                  <p className="text-gray-600">
                    Personaliza los colores principales de tu bar
                  </p>
                </div>
                <div className="text-sm">
                  <h4 className="font-medium mb-1">Tipografía</h4>
                  <p className="text-gray-600">
                    Cambia la fuente y tamaño del texto
                  </p>
                </div>
                <div className="text-sm">
                  <h4 className="font-medium mb-1">Imágenes</h4>
                  <p className="text-gray-600">
                    Sube tu logo e imagen de fondo
                  </p>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  )
}

export default function PersonalizacionMesasPage() {
  return (
    <Suspense fallback={
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-500 mx-auto mb-4"></div>
          <p>Cargando personalización...</p>
        </div>
      </div>
    }>
      <PersonalizacionMesasContent />
    </Suspense>
  )
}