export interface User {
  uid: string
  email?: string
  role: "super_admin" | "bar_admin" | "guest"
  barId?: string
  createdAt: Date
}

export interface Bar {
  id: string
  name: string
  address: string
  adminIds: string[]
  isActive: boolean
  createdAt: Date
}

export interface Table {
  id: string
  barId: string
  number: number
  capacity?: number // Agregado campo capacity para reservas
  isActive: boolean
  isOccupied?: boolean // Agregado campo para ocupación manual
  occupiedBy?: string // Agregado campo opcional para identificar quién ocupa la mesa
  occupiedAt?: Date // Agregado campo para timestamp de ocupación
  password?: string // Agregado campo opcional para contraseña de mesa
  customization?: {
    backgroundColor?: string
    textColor?: string
    primaryColor?: string
    secondaryColor?: string
    logoUrl?: string
    fontFamily?: string
    borderRadius?: string
    backgroundImage?: string
    backgroundOpacity?: number
  }
  createdAt: Date
}

export interface MenuItem {
  id: string
  barId: string
  categoryId: string
  name: string
  description?: string
  price: number
  isAvailable: boolean
  imageUrl?: string
  promotion?: string
  promotionPrice?: number
}

export interface MenuCategory {
  id: string
  barId: string
  name: string
  order: number
}

export interface Order {
  id: string
  barId: string
  tableId: string
  tableNumber: number // agregado número de mesa destino
  senderTableId?: string // agregado ID de mesa origen
  senderTableNumber?: number // agregado número de mesa origen
  customerName?: string // Added customer information fields
  customerPhone?: string // Added customer information fields
  accountType?: "shared" | "individual" // Added customer information fields
  items: OrderItem[]
  status: "pending" | "confirmed" | "preparing" | "ready" | "delivered" | "cancelled"
  total: number
  createdAt: Date
  updatedAt: Date
}

export interface OrderItem {
  menuItemId: string
  name: string
  price: number
  promotionPrice?: number
  quantity: number
  notes?: string
}

export interface Message {
  id: string
  chatId: string // Combinación de tableIds ordenados: "table1-table2"
  barId: string
  type: "text" | "gif" | "order"
  text: string
  orderId?: string
  senderTable: string // Mesa que envía el mensaje
  senderTableNumber: number // Número de mesa que envía
  senderId: string // ID del usuario que envía
  timestamp: Date
  createdAt: Date
}

export interface TableChat {
  id: string // Combinación de tableIds: "table1-table2"
  barId: string
  tableIds: string[] // IDs de las dos mesas
  tableNumbers: number[] // Números de las dos mesas
  lastMessage?: string
  lastMessageAt?: Date
  isActive: boolean
  createdAt: Date
}

export interface WaiterCall {
  id: string
  barId: string
  tableId: string
  tableNumber: number
  message?: string
  status: "pending" | "attending" | "resolved"
  createdAt: Date
  updatedAt: Date
}

export interface BarConfiguration {
  id: string
  barId: string
  name: string
  address: string
  phone: string
  email: string
  website?: string
  openingHours: {
    [key: string]: { open: string; close: string } | null
  }
  features: {
    chatEnabled: boolean
    ordersEnabled: boolean
    reservationsEnabled: boolean
    waiterCallsEnabled: boolean
    crmEnabled: boolean
    announcementsEnabled: boolean
  }
  notifications: {
    newOrderSound: boolean
    newOrderNotification: boolean
    newReservationNotification: boolean
    newWaiterCallNotification: boolean
  }
  theme: {
    primaryColor: string
    secondaryColor: string
    logoUrl?: string
    backgroundImageUrl?: string
  }
  createdAt: Date
  updatedAt: Date
}

export interface ThemeConfig {
  id: string
  barId: string
  colors: {
    primary: string
    secondary: string
    background: string
    text: string
    surface: string
    menuText: string
    success: string
    danger: string
  }
  typography: {
    fontFamily: string
    fontSize: string
    fontWeight: string
  }
  assets: {
    logoUrl?: string
    backgroundImageUrl?: string
    faviconUrl?: string
  }
  branding: {
    restaurantName: string
    tagline?: string
    description?: string
    contactInfo?: string
  }
  menuCustomization: {
    borderRadius: number
    cardStyle: string
    layout: string
  }
  createdAt: Date
  updatedAt: Date
}

export interface ServiceRating {
  id: string
  barId: string
  tableId: string
  tableNumber: number
  rating: number
  comment?: string
  anonymous: boolean
  customerData?: {
    name?: string
    email?: string
    phone?: string
  }
  createdAt: Date
  updatedAt: Date
}

export interface Reservation {
  id: string
  barId: string
  tableId: string
  tableNumber: number
  customerName: string
  customerPhone: string
  customerEmail?: string
  partySize: number
  reservationDate: Date
  reservationTime: string
  status: 'pending' | 'confirmed' | 'cancelled' | 'completed' | 'no_show'
  specialRequests?: string
  notes?: string
  createdAt: Date
  updatedAt: Date
}

export interface ReservationConfig {
  barId: string
  openingTime: string // "09:00"
  closingTime: string // "23:00"
  slotDuration: number // minutos entre slots (ej: 30)
  maxPartySize: number
  minPartySize: number
  advanceBookingDays: number // días de anticipación máxima
  advanceBookingHours: number // horas de anticipación mínima
  isActive: boolean
  reservationDurationMinutes: number // duración de cada reserva en minutos
  specialHours?: {
    [dayOfWeek: string]: {
      openingTime: string
      closingTime: string
    }
  }
  createdAt: Date
  updatedAt: Date
}
