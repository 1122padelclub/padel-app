"use client"

import { useState, useEffect } from "react"
import { ref, onValue, push, set, update } from "firebase/database"
import { getRealtimeDbInstance } from "@/lib/firebase"
import type { Order, OrderItem } from "@/src/types"

export function useOrders(barId: string) {
  const [orders, setOrders] = useState<Order[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    if (typeof window === "undefined" || !barId) {
      setLoading(false)
      return
    }

    setLoading(true)

    const realtimeDbInstance = getRealtimeDbInstance()
    if (!realtimeDbInstance) {
      setLoading(false)
      return
    }

    // Escuchar pedidos en tiempo real desde Realtime Database
    const ordersRef = ref(realtimeDbInstance, `orders/${barId}`)
    const unsubscribe = onValue(
      ordersRef,
      (snapshot) => {
        const ordersData = snapshot.val()
        if (ordersData) {
          const ordersList: Order[] = Object.entries(ordersData).map(([id, data]: [string, any]) => ({
            id,
            ...data,
            createdAt: new Date(data.createdAt),
            updatedAt: new Date(data.updatedAt),
          }))

          // Ordenar por fecha de creación (más recientes primero)
          ordersList.sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime())
          setOrders(ordersList)
        } else {
          setOrders([])
        }
        setLoading(false)
      },
      (error) => {
        console.error("[v0] Error loading orders:", error)
        if (error.code === "PERMISSION_DENIED") {
          console.warn("Permisos insuficientes para orders, verificar reglas de Firebase Realtime Database")
        }
        setOrders([])
        setLoading(false)
      },
    )

    return () => unsubscribe()
  }, [barId])

  const createOrder = async (
    tableId: string,
    items: OrderItem[],
    tableNumber?: number,
    customerInfo?: any,
  ): Promise<string | null> => {
    try {
      if (typeof window === "undefined") return null

      const realtimeDbInstance = getRealtimeDbInstance()
      if (!realtimeDbInstance) return null

      const total = items.reduce((sum, item) => sum + (item.promotionPrice || item.price) * item.quantity, 0)

      const orderData: Omit<Order, "id"> = {
        barId,
        tableId,
        tableNumber: tableNumber || 0,
        items,
        status: "pending",
        total,
        createdAt: new Date(),
        updatedAt: new Date(),
        ...(customerInfo && {
          customerName: customerInfo.name,
          customerPhone: customerInfo.phone,
          accountType: customerInfo.accountType,
        }),
      }

      // Crear pedido en Realtime Database
      const ordersRef = ref(realtimeDbInstance, `orders/${barId}`)
      const newOrderRef = push(ordersRef)
      await set(newOrderRef, {
        ...orderData,
        createdAt: orderData.createdAt.toISOString(),
        updatedAt: orderData.updatedAt.toISOString(),
      })

      console.log("[v0] Pedido creado exitosamente:", newOrderRef.key)
      return newOrderRef.key
    } catch (error) {
      console.error("[v0] Error creating order:", error)
      return null
    }
  }

  const updateOrderStatus = async (orderId: string, status: Order["status"]): Promise<boolean> => {
    try {
      if (typeof window === "undefined") return false

      const realtimeDbInstance = getRealtimeDbInstance()
      if (!realtimeDbInstance) return false

      const orderRef = ref(realtimeDbInstance, `orders/${barId}/${orderId}`)
      await update(orderRef, {
        status,
        updatedAt: new Date().toISOString(),
      })

      console.log("[v0] Estado del pedido actualizado:", orderId, status)
      return true
    } catch (error) {
      console.error("[v0] Error updating order status:", error)
      return false
    }
  }

  const getOrdersByStatus = (status: Order["status"]) => {
    return orders.filter((order) => order.status === status)
  }

  const getOrdersByTable = (tableId: string) => {
    return orders.filter((order) => order.tableId === tableId)
  }

  return {
    orders,
    loading,
    createOrder,
    updateOrderStatus,
    getOrdersByStatus,
    getOrdersByTable,
  }
}
