"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Calendar, Clock, Users, Phone, Mail, MapPin, CheckCircle, X } from "lucide-react"
import { useReservationConfig } from "@/src/hooks/useReservationConfig"
import { useReservations } from "@/src/hooks/useReservations"
import { useAvailableTables } from "@/src/hooks/useAvailableTables"
import { useThemeConfig } from "@/src/hooks/useThemeConfig"
import { format, addDays, isToday, isTomorrow } from "date-fns"
import { es } from "date-fns/locale"
import type { Reservation } from "@/src/types"

interface ReservationPageClientProps {
  barId: string
}

export function ReservationPageClient({ barId }: ReservationPageClientProps) {
  const { themeConfig, isLoading: themeLoading } = useThemeConfig(barId)
  const { config, loading: configLoading, generateTimeSlots, isDateAvailable } = useReservationConfig(barId)
  const { createReservation } = useReservations(barId)
  
  const [selectedDate, setSelectedDate] = useState<Date>(new Date())
  const [selectedTime, setSelectedTime] = useState<string>("")
  const [selectedTable, setSelectedTable] = useState<string>("")
  const [formData, setFormData] = useState({
    customerName: "",
    customerPhone: "",
    customerEmail: "",
    partySize: 1,
    specialRequests: ""
  })
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [submitted, setSubmitted] = useState(false)

  const availableTimeSlots = generateTimeSlots(selectedDate)
  
  // Obtener mesas disponibles basadas en fecha y hora seleccionadas
  const durationMinutes = config?.reservationDurationMinutes || 120
  const { 
    availableTables, 
    loading: tablesLoading, 
    error: tablesError,
    totalTables,
    activeTables 
  } = useAvailableTables(barId, selectedDate, selectedTime, durationMinutes)

  // Debug logs para verificar las mesas
  console.log("🪑 Debug - Mesas disponibles:", {
    totalTables,
    activeTables,
    availableTables: availableTables.length,
    selectedDate: selectedDate?.toISOString(),
    selectedTime,
    durationMinutes,
    barId
  })

  const handleDateChange = (date: Date) => {
    setSelectedDate(date)
    setSelectedTime("")
    setSelectedTable("")
  }

  const handleTimeChange = (time: string) => {
    setSelectedTime(time)
    setSelectedTable("")
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    
    if (!selectedTable || !selectedTime || !config) return

    setIsSubmitting(true)
    try {
      const table = availableTables.find(t => t.id === selectedTable)
      if (!table) throw new Error("Mesa no encontrada")

      const reservationData: Omit<Reservation, "id" | "createdAt" | "updatedAt"> = {
        barId,
        tableId: selectedTable,
        tableNumber: table.number,
        customerName: formData.customerName,
        customerPhone: formData.customerPhone,
        customerEmail: formData.customerEmail || "",
        partySize: formData.partySize,
        reservationDate: selectedDate,
        reservationTime: selectedTime,
        status: 'pending',
        specialRequests: formData.specialRequests || "",
      }

      // Obtener duración de la configuración
      const durationMinutes = config?.reservationDurationMinutes || 120
      await createReservation(reservationData, durationMinutes)
      setSubmitted(true)
    } catch (error) {
      console.error("Error creando reserva:", error)
      alert("Error al crear la reserva. Por favor, intenta de nuevo.")
    } finally {
      setIsSubmitting(false)
    }
  }

  const getDateLabel = (date: Date) => {
    if (isToday(date)) return "Hoy"
    if (isTomorrow(date)) return "Mañana"
    return format(date, 'EEEE, dd MMMM', { locale: es })
  }

  if (themeLoading || configLoading || tablesLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
      </div>
    )
  }

  if (!config?.isActive) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Card className="max-w-md">
          <CardContent className="p-6 text-center">
            <X className="h-12 w-12 text-red-500 mx-auto mb-4" />
            <h2 className="text-xl font-semibold mb-2">Reservas No Disponibles</h2>
            <p className="text-muted-foreground">
              El sistema de reservas no está activo en este momento.
            </p>
          </CardContent>
        </Card>
      </div>
    )
  }

  if (submitted) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Card className="max-w-md">
          <CardContent className="p-6 text-center">
            <CheckCircle className="h-12 w-12 text-green-500 mx-auto mb-4" />
            <h2 className="text-xl font-semibold mb-2">¡Reserva Solicitada!</h2>
            <p className="text-muted-foreground mb-4">
              Tu reserva ha sido enviada y será confirmada pronto.
            </p>
            <Button 
              onClick={() => {
                setSubmitted(false)
                setFormData({
                  customerName: "",
                  customerPhone: "",
                  customerEmail: "",
                  partySize: 1,
                  specialRequests: ""
                })
                setSelectedDate(new Date())
                setSelectedTime("")
                setSelectedTable("")
              }}
              className="w-full"
            >
              Hacer Otra Reserva
            </Button>
          </CardContent>
        </Card>
      </div>
    )
  }

  return (
    <div 
      className="min-h-screen"
      style={{
        background: (themeConfig?.assets as any)?.backgroundImageUrl
          ? `url(${(themeConfig.assets as any).backgroundImageUrl}) center/cover`
          : `linear-gradient(135deg, ${(themeConfig?.branding as any)?.primaryColor || '#0ea5e9'}, ${(themeConfig?.branding as any)?.secondaryColor || '#1f2937'})`,
        fontFamily: (themeConfig?.branding as any)?.fontFamily || "system-ui, sans-serif",
      }}
    >
      <div className="container mx-auto px-4 py-8">
        <div className="max-w-4xl mx-auto">
          {/* Header */}
          <div className="text-center mb-8">
            <h1 
              className="text-4xl font-bold mb-2"
              style={{ color: (themeConfig?.branding as any)?.textColor || '#ffffff' }}
            >
              {(themeConfig?.branding as any)?.restaurantName || 'Reservas'}
            </h1>
            <p 
              className="text-lg opacity-90"
              style={{ color: (themeConfig?.branding as any)?.textColor || '#ffffff' }}
            >
              {(themeConfig?.branding as any)?.tagline || 'Reserva tu mesa'}
            </p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            {/* Formulario de Reserva */}
            <Card className="rounded-2xl">
              <CardHeader>
                <CardTitle className="font-serif flex items-center gap-2">
                  <Calendar className="h-5 w-5" />
                  Nueva Reserva
                </CardTitle>
              </CardHeader>
              <CardContent>
                <form onSubmit={handleSubmit} className="space-y-6">
                  {/* Fecha */}
                  <div>
                    <Label htmlFor="date">Fecha</Label>
                    <div className="flex gap-2 mt-2">
                      {[0, 1, 2, 3, 4, 5, 6].map((days) => {
                        const date = addDays(new Date(), days)
                        const isAvailable = isDateAvailable(date)
                        const isSelected = selectedDate.toDateString() === date.toDateString()
                        
                        return (
                          <Button
                            key={days}
                            type="button"
                            variant={isSelected ? "default" : "outline"}
                            disabled={!isAvailable}
                            onClick={() => handleDateChange(date)}
                            className="flex-1 text-xs"
                          >
                            <div className="text-center">
                              <div className="font-semibold">{format(date, 'dd')}</div>
                              <div className="text-xs opacity-70">{format(date, 'MMM')}</div>
                            </div>
                          </Button>
                        )
                      })}
                    </div>
                    <p className="text-sm text-muted-foreground mt-2">
                      {getDateLabel(selectedDate)}
                    </p>
                  </div>

                  {/* Hora */}
                  <div>
                    <Label htmlFor="time">Hora</Label>
                    <Select value={selectedTime} onValueChange={handleTimeChange}>
                      <SelectTrigger className="rounded-xl">
                        <Clock className="h-4 w-4 mr-2" />
                        <SelectValue placeholder="Selecciona una hora" />
                      </SelectTrigger>
                      <SelectContent>
                        {availableTimeSlots.map((time) => (
                          <SelectItem key={time} value={time}>
                            {time}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  {/* Mesa */}
                  <div>
                    <Label htmlFor="table">Mesa</Label>
                    <Select value={selectedTable} onValueChange={setSelectedTable}>
                      <SelectTrigger className="rounded-xl">
                        <MapPin className="h-4 w-4 mr-2" />
                        <SelectValue placeholder="Selecciona una mesa" />
                      </SelectTrigger>
                      <SelectContent>
                        {availableTables.length === 0 ? (
                          <div className="p-4 text-center text-muted-foreground">
                            <p>No hay mesas disponibles para este horario</p>
                            <p className="text-xs mt-1">
                              Total mesas: {totalTables} | Activas: {activeTables} | Disponibles: {availableTables.length}
                            </p>
                            {selectedTime && (
                              <p className="text-xs mt-2 text-orange-600">
                                💡 Intenta con otro horario o fecha
                              </p>
                            )}
                          </div>
                        ) : (
                          availableTables.map((table) => (
                            <SelectItem key={table.id} value={table.id}>
                              Mesa {table.number} - {table.capacity || 4} personas
                            </SelectItem>
                          ))
                        )}
                      </SelectContent>
                    </Select>
                  </div>

                  {/* Información del Cliente */}
                  <div className="space-y-4">
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <Label htmlFor="customerName">Nombre *</Label>
                        <Input
                          id="customerName"
                          value={formData.customerName}
                          onChange={(e) => setFormData({ ...formData, customerName: e.target.value })}
                          required
                          className="rounded-xl"
                        />
                      </div>
                      <div>
                        <Label htmlFor="customerPhone">Teléfono *</Label>
                        <Input
                          id="customerPhone"
                          type="tel"
                          value={formData.customerPhone}
                          onChange={(e) => setFormData({ ...formData, customerPhone: e.target.value })}
                          required
                          className="rounded-xl"
                        />
                      </div>
                    </div>

                    <div>
                      <Label htmlFor="customerEmail">Email</Label>
                      <Input
                        id="customerEmail"
                        type="email"
                        value={formData.customerEmail}
                        onChange={(e) => setFormData({ ...formData, customerEmail: e.target.value })}
                        className="rounded-xl"
                      />
                    </div>

                    <div>
                      <Label htmlFor="partySize">Número de Personas *</Label>
                      <Select 
                        value={formData.partySize.toString()} 
                        onValueChange={(value) => setFormData({ ...formData, partySize: parseInt(value) })}
                      >
                        <SelectTrigger className="rounded-xl">
                          <Users className="h-4 w-4 mr-2" />
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          {Array.from({ length: config.maxPartySize }, (_, i) => i + 1).map((size) => (
                            <SelectItem key={size} value={size.toString()}>
                              {size} {size === 1 ? 'persona' : 'personas'}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>

                    <div>
                      <Label htmlFor="specialRequests">Solicitudes Especiales</Label>
                      <Textarea
                        id="specialRequests"
                        value={formData.specialRequests}
                        onChange={(e) => setFormData({ ...formData, specialRequests: e.target.value })}
                        placeholder="Alergias, celebraciones especiales, etc."
                        className="rounded-xl"
                        rows={3}
                      />
                    </div>
                  </div>

                  <Button 
                    type="submit" 
                    disabled={!selectedTable || !selectedTime || isSubmitting}
                    className="w-full rounded-xl py-3 text-lg"
                  >
                    {isSubmitting ? "Enviando..." : "Solicitar Reserva"}
                  </Button>
                </form>
              </CardContent>
            </Card>

            {/* Información del Bar */}
            <Card className="rounded-2xl">
              <CardHeader>
                <CardTitle className="font-serif">Información</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center gap-3">
                  <Clock className="h-5 w-5 text-blue-500" />
                  <div>
                    <p className="font-medium">Horario de Atención</p>
                    <p className="text-sm text-muted-foreground">
                      {config?.openingTime} - {config?.closingTime}
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-3">
                  <Users className="h-5 w-5 text-green-500" />
                  <div>
                    <p className="font-medium">Capacidad</p>
                    <p className="text-sm text-muted-foreground">
                      {config?.minPartySize} - {config?.maxPartySize} personas por mesa
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-3">
                  <Calendar className="h-5 w-5 text-purple-500" />
                  <div>
                    <p className="font-medium">Anticipación</p>
                    <p className="text-sm text-muted-foreground">
                      Mínimo {config?.advanceBookingHours}h, máximo {config?.advanceBookingDays} días
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-3">
                  <MapPin className="h-5 w-5 text-red-500" />
                  <div>
                    <p className="font-medium">Mesas Disponibles</p>
                    <p className="text-sm text-muted-foreground">
                      {availableTables.length} mesas activas
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  )
}
