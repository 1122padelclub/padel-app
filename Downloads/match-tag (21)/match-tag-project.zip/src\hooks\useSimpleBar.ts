"use client"
import { useState, useEffect } from "react"
import { TableManager } from "@/src/utils/tableManager"

interface SimpleBar {
  id: string
  name: string
  logoUrl?: string
  theme?: {
    primaryColor?: string
    secondaryColor?: string
    textColor?: string
    bgImage?: string
  }
}

export function useSimpleBar(barId?: string) {
  const [bar, setBar] = useState<SimpleBar | null>(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    if (typeof window === "undefined" || !barId) {
      setLoading(false)
      return
    }

    setLoading(true)
    console.log("[v0] Loading simple bar for barId:", barId)

    try {
      // Obtener barra del localStorage
      const barData = TableManager.getBar(barId)
      
      if (barData) {
        setBar(barData)
      } else {
        // Fallback a datos por defecto
        const defaultBar: SimpleBar = {
          id: barId,
          name: "Match Tag Bar",
          logoUrl: null,
          theme: {
            primaryColor: "#0ea5e9",
            secondaryColor: "#1f2937",
            textColor: "#ffffff",
            bgImage: null,
          }
        }
        setBar(defaultBar)
      }
      
      setLoading(false)
      setError(null)
    } catch (error) {
      console.error("[v0] Error loading bar:", error)
      setError("Error loading bar data")
      setLoading(false)
    }
  }, [barId])

  return { bar, loading, error }
}
