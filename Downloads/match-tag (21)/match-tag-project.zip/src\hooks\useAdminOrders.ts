"use client"

import { useEffect, useState, useRef } from "react"
import { ref, onValue, update } from "firebase/database"
import { realtimeDb } from "@/src/services/firebaseExtras"
import type { Order } from "@/src/types"

export function useAdminOrders(barId: string) {
  const [orders, setOrders] = useState<Order[]>([])
  const [loading, setLoading] = useState(true)
  const previousOrdersCount = useRef(0)

  useEffect(() => {
    if (!barId) return

    console.log("[v0] useAdminOrders iniciando para barId:", barId)
    setLoading(true)

    const ordersRef = ref(realtimeDb, `orders/${barId}`)
    const unsubscribe = onValue(
      ordersRef,
      (snapshot) => {
        const ordersData = snapshot.val()
        console.log("[v0] Datos de pedidos recibidos desde Realtime DB:", ordersData)

        if (ordersData) {
          const ordersList: Order[] = Object.entries(ordersData).map(([id, data]: [string, any]) => ({
            id,
            ...data,
            createdAt: new Date(data.createdAt),
            updatedAt: new Date(data.updatedAt),
          }))

          // Ordenar por fecha de creación (más recientes primero)
          ordersList.sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime())

          const currentOrdersCount = ordersList.length
          if (previousOrdersCount.current > 0 && currentOrdersCount > previousOrdersCount.current) {
            // Nuevo pedido detectado
            try {
              const audio = new Audio("/notification-sound.mp3")
              audio.volume = 0.5
              audio.play().catch((e) => console.log("[v0] No se pudo reproducir sonido:", e))
            } catch (error) {
              console.log("[v0] Error reproduciendo sonido:", error)
            }

            // Mostrar notificación del navegador si está permitido
            if ("Notification" in window && Notification.permission === "granted") {
              new Notification("Nuevo Pedido", {
                body: "Se ha recibido un nuevo pedido",
                icon: "/icon-192.png",
              })
            }
          }
          previousOrdersCount.current = currentOrdersCount

          setOrders(ordersList)
          console.log("[v0] Pedidos procesados:", ordersList.length)
        } else {
          setOrders([])
          previousOrdersCount.current = 0
          console.log("[v0] No hay pedidos en la base de datos")
        }
        setLoading(false)
      },
      (error) => {
        console.error("[v0] Error al obtener pedidos:", error)
        setLoading(false)
      },
    )

    return () => unsubscribe()
  }, [barId])

  useEffect(() => {
    if ("Notification" in window && Notification.permission === "default") {
      Notification.requestPermission()
    }
  }, [])

  const updateOrderStatus = async (orderId: string, status: Order["status"]) => {
    try {
      console.log("[v0] Actualizando estado del pedido:", orderId, "a", status)

      const orderRef = ref(realtimeDb, `orders/${barId}/${orderId}`)
      await update(orderRef, {
        status,
        updatedAt: new Date().toISOString(),
      })

      console.log("[v0] Estado del pedido actualizado exitosamente")
      return true
    } catch (error) {
      console.error("[v0] Error updating order status:", error)
      return false
    }
  }

  const getOrdersByStatus = (status: Order["status"]) => {
    return orders.filter((order) => order.status === status)
  }

  return {
    orders,
    loading,
    updateOrderStatus,
    getOrdersByStatus,
  }
}
