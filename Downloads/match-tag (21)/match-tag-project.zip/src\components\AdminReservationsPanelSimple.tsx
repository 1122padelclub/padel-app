"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Calendar, Clock, Users, Phone, Mail, ExternalLink } from "lucide-react"
import Link from "next/link"
import { useReservations } from "@/src/hooks/useReservations"
import { useReservationNotifications } from "@/src/hooks/useReservationNotifications"
import { ReservationDurationConfig } from "./ReservationDurationConfig"
import { format } from "date-fns"
import { es } from "date-fns/locale"
import type { Reservation } from "@/src/types"

interface AdminReservationsPanelProps {
  barId: string
}

export function AdminReservationsPanelSimple({ barId }: AdminReservationsPanelProps) {
  const { reservations, loading, error, updateReservation, deleteReservation, getReservationsByStatus } = useReservations(barId)
  const { sendNotification, isLoading: notificationLoading } = useReservationNotifications()
  
  const [searchTerm, setSearchTerm] = useState("")
  const [statusFilter, setStatusFilter] = useState<string>("all")

  const filteredReservations = reservations.filter((reservation) => {
    const matchesSearch = 
      reservation.customerName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      reservation.customerPhone.includes(searchTerm) ||
      (reservation.customerEmail && reservation.customerEmail.toLowerCase().includes(searchTerm.toLowerCase())) ||
      `mesa ${reservation.tableNumber}`.includes(searchTerm.toLowerCase())

    const matchesStatus = statusFilter === "all" || reservation.status === statusFilter

    return matchesSearch && matchesStatus
  })

  const pendingReservations = getReservationsByStatus('pending')
  const confirmedReservations = getReservationsByStatus('confirmed')

  const handleConfirmReservation = async (reservation: Reservation) => {
    try {
      // Actualizar estado a confirmada
      await updateReservation(reservation.id, { status: 'confirmed' })
      
      // Enviar notificación
      await sendNotification({
        customerName: reservation.customerName,
        customerEmail: reservation.customerEmail,
        customerPhone: reservation.customerPhone,
        reservationDate: reservation.reservationDate,
        reservationTime: reservation.reservationTime,
        tableNumber: reservation.tableNumber,
        partySize: reservation.partySize,
        barName: "Nuestro Restaurante"
      })
      
      console.log("✅ Reserva confirmada y notificación enviada")
    } catch (error) {
      console.error("❌ Error confirmando reserva:", error)
    }
  }

  const handleDeleteReservation = async (reservationId: string) => {
    if (confirm("¿Estás seguro de que quieres eliminar esta reserva?")) {
      try {
        await deleteReservation(reservationId)
      } catch (error) {
        console.error("Error eliminando reserva:", error)
      }
    }
  }

  const getStatusColor = (status: Reservation['status']) => {
    switch (status) {
      case 'pending': return 'bg-yellow-100 text-yellow-800'
      case 'confirmed': return 'bg-green-100 text-green-800'
      case 'cancelled': return 'bg-red-100 text-red-800'
      case 'completed': return 'bg-blue-100 text-blue-800'
      case 'no_show': return 'bg-gray-100 text-gray-800'
      default: return 'bg-gray-100 text-gray-800'
    }
  }

  const getStatusText = (status: Reservation['status']) => {
    switch (status) {
      case 'pending': return 'Pendiente'
      case 'confirmed': return 'Confirmada'
      case 'cancelled': return 'Cancelada'
      case 'completed': return 'Completada'
      case 'no_show': return 'No se presentó'
      default: return 'Desconocido'
    }
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center p-8">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Gestión de Reservas</h1>
          <p className="text-gray-600 mt-1">Administra las reservas del restaurante</p>
        </div>
        <Link
          href={`/reservar/${barId}`}
          target="_blank"
          rel="noopener noreferrer"
          className="flex items-center gap-2 px-4 py-2 bg-green-500 text-white rounded-xl hover:bg-green-600 transition-colors"
        >
          <ExternalLink className="h-4 w-4" />
          Ver Página de Reservas
        </Link>
      </div>

      {/* Estadísticas - Más prominentes */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
        <Card className="rounded-xl border-l-4 border-l-yellow-500">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Pendientes</p>
                <p className="text-3xl font-bold text-yellow-600">{pendingReservations.length}</p>
                <p className="text-xs text-gray-500 mt-1">Requieren confirmación</p>
              </div>
              <Clock className="h-8 w-8 text-yellow-500" />
            </div>
          </CardContent>
        </Card>
        
        <Card className="rounded-xl border-l-4 border-l-green-500">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Confirmadas</p>
                <p className="text-3xl font-bold text-green-600">{confirmedReservations.length}</p>
                <p className="text-xs text-gray-500 mt-1">Listas para el servicio</p>
              </div>
              <Calendar className="h-8 w-8 text-green-500" />
            </div>
          </CardContent>
        </Card>
        
        <Card className="rounded-xl border-l-4 border-l-blue-500">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Total Reservas</p>
                <p className="text-3xl font-bold text-blue-600">{reservations.length}</p>
                <p className="text-xs text-gray-500 mt-1">Todas las reservas</p>
              </div>
              <Users className="h-8 w-8 text-blue-500" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Filtros - Más compactos */}
      <Card className="rounded-xl mb-6">
        <CardContent className="p-4">
          <div className="flex flex-col sm:flex-row gap-4">
            <div className="relative flex-1">
              <Input
                placeholder="🔍 Buscar por nombre, teléfono, email o mesa..."
                className="rounded-xl"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>
            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger className="w-full sm:w-[200px] rounded-xl">
                <SelectValue placeholder="Filtrar por estado" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Todos los estados</SelectItem>
                <SelectItem value="pending">Pendientes</SelectItem>
                <SelectItem value="confirmed">Confirmadas</SelectItem>
                <SelectItem value="cancelled">Canceladas</SelectItem>
                <SelectItem value="completed">Completadas</SelectItem>
                <SelectItem value="no_show">No se presentó</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      {/* Lista de Reservas */}
      <Card className="rounded-xl">
        <CardHeader>
          <CardTitle>Reservas</CardTitle>
          <CardDescription>
            {filteredReservations.length} reserva{filteredReservations.length !== 1 ? 's' : ''} encontrada{filteredReservations.length !== 1 ? 's' : ''}
          </CardDescription>
        </CardHeader>
        <CardContent>
          {filteredReservations.length === 0 ? (
            <div className="text-center text-muted-foreground py-8">
              <Calendar className="h-12 w-12 mx-auto mb-4 opacity-50" />
              <p>No hay reservas que coincidan con los filtros</p>
            </div>
          ) : (
            <ScrollArea className="h-[400px]">
              <div className="space-y-4">
                {filteredReservations.map((reservation) => (
                  <Card key={reservation.id} className="rounded-xl">
                    <CardContent className="p-4">
                      <div className="flex items-center justify-between">
                        <div className="flex-1">
                          <div className="flex items-center gap-4 mb-2">
                            <h3 className="font-semibold text-lg">{reservation.customerName}</h3>
                            <Badge className={`${getStatusColor(reservation.status)} rounded-full`}>
                              {getStatusText(reservation.status)}
                            </Badge>
                          </div>
                          
                          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm text-gray-600">
                            <div className="flex items-center gap-2">
                              <Calendar className="h-4 w-4" />
                              <span>{format(reservation.reservationDate, 'PPP', { locale: es })}</span>
                            </div>
                            <div className="flex items-center gap-2">
                              <Clock className="h-4 w-4" />
                              <span>{reservation.reservationTime}</span>
                            </div>
                            <div className="flex items-center gap-2">
                              <Users className="h-4 w-4" />
                              <span>{reservation.partySize} persona{reservation.partySize !== 1 ? 's' : ''}</span>
                            </div>
                            <div className="flex items-center gap-2">
                              <span className="font-medium">Mesa {reservation.tableNumber}</span>
                            </div>
                            {reservation.customerPhone && (
                              <div className="flex items-center gap-2">
                                <Phone className="h-4 w-4" />
                                <span>{reservation.customerPhone}</span>
                              </div>
                            )}
                            {reservation.customerEmail && (
                              <div className="flex items-center gap-2">
                                <Mail className="h-4 w-4" />
                                <span>{reservation.customerEmail}</span>
                              </div>
                            )}
                          </div>
                          
                          {reservation.specialRequests && (
                            <div className="mt-2 p-2 bg-gray-50 rounded-lg">
                              <p className="text-sm text-gray-600">
                                <strong>Solicitudes especiales:</strong> {reservation.specialRequests}
                              </p>
                            </div>
                          )}
                        </div>
                        
                        <div className="flex gap-2 ml-4">
                          {reservation.status === 'pending' && (
                            <Button
                              variant="default"
                              size="sm"
                              onClick={() => handleConfirmReservation(reservation)}
                              disabled={notificationLoading}
                              className="bg-green-600 hover:bg-green-700"
                            >
                              {notificationLoading ? "Enviando..." : "Confirmar"}
                            </Button>
                          )}
                          
                          <Button
                            variant="destructive"
                            size="sm"
                            onClick={() => handleDeleteReservation(reservation.id)}
                          >
                            Eliminar
                          </Button>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </ScrollArea>
          )}
        </CardContent>
      </Card>

      {/* Configuración de Duración - Movida al final */}
      <ReservationDurationConfig barId={barId} />
    </div>
  )
}
