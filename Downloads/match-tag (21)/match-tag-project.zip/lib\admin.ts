export { getAdminApp, getAdminDb, adminSetDoc, adminGetDoc, adminUpdateDoc } from "./firebaseAdmin"
export { getAdminDb as adb } from "./firebaseAdmin"
