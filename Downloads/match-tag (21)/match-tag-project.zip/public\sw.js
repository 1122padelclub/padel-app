const CACHE_VERSION = "v2" // Incrementar cuando hay cambios de UI/tema
const CACHE_NAME = `match-tag-${CACHE_VERSION}`
const STATIC_CACHE = `match-tag-static-${CACHE_VERSION}`
const DYNAMIC_CACHE = `match-tag-dynamic-${CACHE_VERSION}`

// Cache shell resources
const STATIC_ASSETS = ["/", "/admin/login", "/admin", "/superadmin", "/manifest.json", "/icon-192.png", "/icon-512.png"]

const NO_CACHE_PATTERNS = [
  /\/mesa\?barId=/,
  /\/reservar\/[^/]+/,
  /\/admin\/personalizacion-mesas/,
  /\/admin\/reservas/,
  /\/api\/bars\//,
  /firestore\.googleapis\.com/,
  /firebase\.googleapis\.com/,
]

// Install event - cache static assets
self.addEventListener("install", (event) => {
  event.waitUntil(
    caches
      .open(STATIC_CACHE)
      .then((cache) => {
        return cache.addAll(STATIC_ASSETS)
      })
      .then(() => {
        return self.skipWaiting()
      }),
  )
})

// Activate event - clean old caches
self.addEventListener("activate", (event) => {
  event.waitUntil(
    caches
      .keys()
      .then((cacheNames) => {
        return Promise.all(
          cacheNames.map((cacheName) => {
            if (!cacheName.includes(CACHE_VERSION)) {
              console.log("[SW] Deleting old cache:", cacheName)
              return caches.delete(cacheName)
            }
          }),
        )
      })
      .then(() => {
        return self.clients.claim()
      }),
  )
})

function shouldNotCache(url) {
  return NO_CACHE_PATTERNS.some((pattern) => pattern.test(url))
}

// Fetch event - serve from cache, fallback to network
self.addEventListener("fetch", (event) => {
  const { request } = event
  const url = new URL(request.url)

  if (request.method !== "GET") {
    return
  }

  if (shouldNotCache(request.url)) {
    console.log("[SW] Bypassing cache for bar-dependent route:", request.url)
    event.respondWith(
      fetch(request, {
        cache: "no-store",
      }).catch(() => {
        // Solo en caso de error de red, intentar caché como último recurso
        return caches.match(request)
      }),
    )
    return
  }

  // Handle API requests (Firestore, Firebase) - sin caché para datos dinámicos
  if (url.hostname.includes("firestore.googleapis.com") || url.hostname.includes("firebase.googleapis.com")) {
    event.respondWith(
      fetch(request, {
        cache: "no-store",
      }),
    )
    return
  }

  // Handle static assets
  if (
    request.destination === "document" ||
    request.destination === "script" ||
    request.destination === "style" ||
    request.destination === "image"
  ) {
    event.respondWith(
      caches.match(request).then((response) => {
        if (response) {
          return response
        }
        return fetch(request).then((response) => {
          if (response.status === 200 && request.method === "GET") {
            const responseClone = response.clone()
            caches.open(DYNAMIC_CACHE).then((cache) => {
              cache.put(request, responseClone)
            })
          }
          return response
        })
      }),
    )
  }
})

self.addEventListener("message", (event) => {
  if (event.data && event.data.type === "INVALIDATE_BAR_CACHE") {
    const barId = event.data.barId
    console.log("[SW] Invalidating cache for bar:", barId)

    // Eliminar entradas de caché relacionadas con este bar
    caches.keys().then((cacheNames) => {
      cacheNames.forEach((cacheName) => {
        caches.open(cacheName).then((cache) => {
          cache.keys().then((requests) => {
            requests.forEach((request) => {
              if (request.url.includes(barId) || shouldNotCache(request.url)) {
                cache.delete(request)
              }
            })
          })
        })
      })
    })
  }
})

// Background sync for offline messages
self.addEventListener("sync", (event) => {
  if (event.tag === "background-sync-messages") {
    event.waitUntil(syncMessages())
  }
})

// Sync offline messages when connection is restored
async function syncMessages() {
  try {
    // Get offline messages from IndexedDB
    const offlineMessages = await getOfflineMessages()

    for (const message of offlineMessages) {
      try {
        // Send message to Firestore
        await self.sendMessageToFirestore(message)
        // Remove from offline storage
        await removeOfflineMessage(message.id)
      } catch (error) {
        console.error("Failed to sync message:", error)
      }
    }
  } catch (error) {
    console.error("Background sync failed:", error)
  }
}

// IndexedDB helpers for offline storage
async function getOfflineMessages() {
  return new Promise((resolve, reject) => {
    const request = indexedDB.open("MatchTagDB", 1)

    request.onsuccess = () => {
      const db = request.result
      const transaction = db.transaction(["messages"], "readonly")
      const store = transaction.objectStore("messages")
      const getRequest = store.getAll()

      getRequest.onsuccess = () => {
        resolve(getRequest.result)
      }
    }

    request.onerror = () => {
      reject(request.error)
    }
  })
}

async function removeOfflineMessage(messageId) {
  return new Promise((resolve, reject) => {
    const request = indexedDB.open("MatchTagDB", 1)

    request.onsuccess = () => {
      const db = request.result
      const transaction = db.transaction(["messages"], "readwrite")
      const store = transaction.objectStore("messages")
      const deleteRequest = store.delete(messageId)

      deleteRequest.onsuccess = () => {
        resolve()
      }
    }

    request.onerror = () => {
      reject(request.error)
    }
  })
}

// Declare sendMessageToFirestore function
self.sendMessageToFirestore = async (message) => {
  // Implementation for sending message to Firestore
  // This is a placeholder implementation
  console.log("Sending message to Firestore:", message)
}
