"use client"

import type React from "react"

import { useState } from "react"
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { User, Users } from "@/src/components/icons/Icons"

interface CustomerInfoModalProps {
  isOpen: boolean
  onClose: () => void
  onConfirm: (customerInfo: CustomerInfo) => void
  tableNumber: number
}

export interface CustomerInfo {
  name: string
  phone?: string
  accountType: "shared" | "individual"
}

export function CustomerInfoModal({ isOpen, onClose, onConfirm, tableNumber }: CustomerInfoModalProps) {
  const [name, setName] = useState("")
  const [phone, setPhone] = useState("")
  const [accountType, setAccountType] = useState<"shared" | "individual">("shared")
  const [isSubmitting, setIsSubmitting] = useState(false)

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!name.trim()) return

    setIsSubmitting(true)

    const customerInfo: CustomerInfo = {
      name: name.trim(),
      phone: phone.trim() || "", // Always provide empty string instead of undefined
      accountType,
    }

    onConfirm(customerInfo)

    // Reset form
    setName("")
    setPhone("")
    setAccountType("shared")
    setIsSubmitting(false)
  }

  const handleClose = () => {
    setName("")
    setPhone("")
    setAccountType("shared")
    onClose()
  }

  return (
    <Dialog open={isOpen} onOpenChange={handleClose}>
      <DialogContent className="max-w-md bg-slate-900 text-white border-slate-700">
        <DialogHeader>
          <DialogTitle className="text-xl font-bold text-center">
            Información del Cliente - Mesa {tableNumber}
          </DialogTitle>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="space-y-4">
            <div>
              <Label htmlFor="name" className="text-sm font-medium text-slate-300">
                Nombre *
              </Label>
              <Input
                id="name"
                type="text"
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="Ingresa tu nombre"
                className="bg-slate-800 border-slate-600 text-white placeholder-slate-400"
                required
              />
            </div>

            <div>
              <Label htmlFor="phone" className="text-sm font-medium text-slate-300">
                Teléfono (opcional)
              </Label>
              <Input
                id="phone"
                type="tel"
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                placeholder="Número de teléfono"
                className="bg-slate-800 border-slate-600 text-white placeholder-slate-400"
              />
            </div>

            <div>
              <Label className="text-sm font-medium text-slate-300 mb-3 block">Tipo de Cuenta</Label>
              <RadioGroup
                value={accountType}
                onValueChange={(value: "shared" | "individual") => setAccountType(value)}
                className="space-y-3"
              >
                <div className="flex items-center space-x-3 p-3 rounded-lg bg-slate-800 border border-slate-700">
                  <RadioGroupItem value="shared" id="shared" className="text-cyan-500" />
                  <Label htmlFor="shared" className="flex items-center gap-2 cursor-pointer flex-1">
                    <Users className="h-5 w-5 text-cyan-400" />
                    <div>
                      <div className="font-medium">Cuenta Compartida</div>
                      <div className="text-sm text-slate-400">Tu pedido se agregará a la cuenta general de la mesa</div>
                    </div>
                  </Label>
                </div>

                <div className="flex items-center space-x-3 p-3 rounded-lg bg-slate-800 border border-slate-700">
                  <RadioGroupItem value="individual" id="individual" className="text-green-500" />
                  <Label htmlFor="individual" className="flex items-center gap-2 cursor-pointer flex-1">
                    <User className="h-5 w-5 text-green-400" />
                    <div>
                      <div className="font-medium">Cuenta Individual</div>
                      <div className="text-sm text-slate-400">Se creará una cuenta separada a tu nombre</div>
                    </div>
                  </Label>
                </div>
              </RadioGroup>
            </div>
          </div>

          <div className="flex gap-3">
            <Button
              type="button"
              variant="outline"
              onClick={handleClose}
              className="flex-1 border-slate-600 text-slate-300 hover:bg-slate-800 bg-transparent"
            >
              Cancelar
            </Button>
            <Button
              type="submit"
              disabled={!name.trim() || isSubmitting}
              className="flex-1 bg-cyan-500 hover:bg-cyan-600 text-white"
            >
              {isSubmitting ? "Procesando..." : "Continuar"}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  )
}
