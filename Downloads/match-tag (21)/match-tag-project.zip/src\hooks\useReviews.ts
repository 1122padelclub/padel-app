"use client"

import { useState, useEffect } from "react"
import { collection, query, orderBy, onSnapshot } from "firebase/firestore"
import { db } from "@/src/services/firebaseExtras"
import type { ServiceRating } from "@/src/types"

export function useReviews(barId: string) {
  const [reviews, setReviews] = useState<ServiceRating[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    if (!barId) {
      setLoading(false)
      return
    }

    console.log("📊 Cargando reseñas para barId:", barId)

    const reviewsRef = collection(db, "bars", barId, "reviews")
    const q = query(reviewsRef, orderBy("createdAt", "desc"))

    const unsubscribe = onSnapshot(
      q,
      (snapshot) => {
        const reviewsData: ServiceRating[] = []
        
        snapshot.forEach((doc) => {
          const data = doc.data()
          reviewsData.push({
            id: doc.id,
            ...data,
            createdAt: data.createdAt?.toDate() || new Date(),
            updatedAt: data.updatedAt?.toDate() || new Date(),
          } as ServiceRating)
        })

        console.log("📊 Reseñas cargadas:", reviewsData.length)
        setReviews(reviewsData)
        setLoading(false)
        setError(null)
      },
      (err) => {
        console.error("❌ Error cargando reseñas:", err)
        setError(err.message)
        setLoading(false)
      }
    )

    return () => unsubscribe()
  }, [barId])

  return { reviews, loading, error }
}
