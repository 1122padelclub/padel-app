"use client"

import type { Table } from "@/components/ui/table"

import type React from "react"

import { useState } from "react"
import { useAdminTables } from "@/src/hooks/useAdminTables"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Badge } from "@/components/ui/badge"
import { Switch } from "@/components/ui/switch"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog"

interface AdminTableListProps {
  barId: string
}

export function AdminTableList({ barId }: AdminTableListProps) {
  const { tables, loading, createTable, updateTable, deleteTable } = useAdminTables(barId)
  const [isCreateOpen, setIsCreateOpen] = useState(false)
  const [newTableNumber, setNewTableNumber] = useState("")
  const [newTablePassword, setNewTablePassword] = useState("")
  const [editPasswordTable, setEditPasswordTable] = useState<string | null>(null)
  const [editPassword, setEditPassword] = useState("")

  const handleCreateTable = async (e: React.FormEvent) => {
    e.preventDefault()
    const number = Number.parseInt(newTableNumber)
    if (isNaN(number) || number <= 0) return

    const success = await createTable(number, newTablePassword || undefined)
    if (success) {
      setIsCreateOpen(false)
      setNewTableNumber("")
      setNewTablePassword("")
    }
  }

  const handleToggleActive = async (tableId: string, isActive: boolean) => {
    await updateTable(tableId, { isActive })
  }

  const handleDeleteTable = async (tableId: string) => {
    await deleteTable(tableId)
  }

  const handleUpdatePassword = async (tableId: string) => {
    const success = await updateTable(tableId, { password: editPassword || undefined })
    if (success) {
      setEditPasswordTable(null)
      setEditPassword("")
    }
  }


  if (loading) {
    return (
      <Card className="rounded-2xl">
        <CardContent className="flex items-center justify-center h-32">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
        </CardContent>
      </Card>
    )
  }

  return (
    <Card className="rounded-2xl">
      <CardHeader>
        <div className="flex justify-between items-center">
          <div>
            <CardTitle className="font-serif">Mesas</CardTitle>
            <CardDescription>Gestionar mesas del bar</CardDescription>
          </div>
          <div className="flex gap-2">
            <Dialog open={isCreateOpen} onOpenChange={setIsCreateOpen}>
              <DialogTrigger asChild>
                <Button className="rounded-xl">Nueva Mesa</Button>
              </DialogTrigger>
              <DialogContent className="rounded-2xl">
                <DialogHeader>
                  <DialogTitle>Crear Nueva Mesa</DialogTitle>
                  <DialogDescription>Ingresa el número y contraseña opcional de la nueva mesa</DialogDescription>
                </DialogHeader>
                <form onSubmit={handleCreateTable} className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="tableNumber">Número de Mesa</Label>
                    <Input
                      id="tableNumber"
                      type="number"
                      min="1"
                      value={newTableNumber}
                      onChange={(e) => setNewTableNumber(e.target.value)}
                      required
                      className="rounded-xl"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="tablePassword">Contraseña (Opcional)</Label>
                    <Input
                      id="tablePassword"
                      type="password"
                      value={newTablePassword}
                      onChange={(e) => setNewTablePassword(e.target.value)}
                      placeholder="Dejar vacío para acceso libre"
                      className="rounded-xl"
                    />
                  </div>
                  <Button type="submit" className="w-full rounded-xl">
                    Crear Mesa
                  </Button>
                </form>
              </DialogContent>
            </Dialog>
          </div>
        </div>
      </CardHeader>
      <CardContent>
        {tables.length === 0 ? (
          <div className="text-center text-muted-foreground py-8">
            <p>No hay mesas creadas</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {tables.map((table) => (
              <Card key={table.id} className="rounded-xl">
                <CardHeader className="pb-3">
                  <div className="flex justify-between items-center">
                    <CardTitle className="text-lg">Mesa {table.number}</CardTitle>
                    <div className="flex gap-2">
                      <Badge variant={table.isActive ? "default" : "secondary"} className="rounded-lg">
                        {table.isActive ? "Activa" : "Inactiva"}
                      </Badge>
                      {table.password && (
                        <Badge variant="outline" className="rounded-lg">
                          🔒
                        </Badge>
                      )}
                    </div>
                  </div>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex items-center justify-between">
                    <Label htmlFor={`active-${table.id}`} className="text-sm">
                      Mesa activa
                    </Label>
                    <Switch
                      id={`active-${table.id}`}
                      checked={table.isActive}
                      onCheckedChange={(checked) => handleToggleActive(table.id, checked)}
                    />
                  </div>
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <Label className="text-sm">Contraseña</Label>
                      <Button
                        variant="outline"
                        size="sm"
                        className="rounded-lg bg-transparent"
                        onClick={() => {
                          setEditPasswordTable(table.id)
                          setEditPassword(table.password || "")
                        }}
                      >
                        {table.password ? "Cambiar" : "Agregar"}
                      </Button>
                    </div>
                    {table.password && (
                      <p className="text-xs text-muted-foreground">
                        Contraseña configurada: {"*".repeat(table.password.length)}
                      </p>
                    )}
                  </div>
                  {/* <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <Label className="text-sm">Diseño</Label>
                      <Button
                        variant="outline"
                        size="sm"
                        className="rounded-lg bg-transparent"
                        onClick={() => handleCustomizeTable(table.id)}
                      >
                        Personalizar
                      </Button>
                    </div>
                  </div> */}
                  <div className="flex gap-2">
                    <Button
                      variant="outline"
                      size="sm"
                      className="flex-1 rounded-lg bg-transparent"
                      onClick={() =>
                        window.open(`/mesa?barId=${barId}&tableId=${table.id}&tableNumber=${table.number}`, "_blank")
                      }
                    >
                      Ver Mesa
                    </Button>
                    <AlertDialog>
                      <AlertDialogTrigger asChild>
                        <Button variant="destructive" size="sm" className="rounded-lg">
                          Eliminar
                        </Button>
                      </AlertDialogTrigger>
                      <AlertDialogContent className="rounded-2xl">
                        <AlertDialogHeader>
                          <AlertDialogTitle>¿Eliminar mesa?</AlertDialogTitle>
                          <AlertDialogDescription>
                            Esta acción no se puede deshacer. Se eliminará la mesa {table.number} permanentemente.
                          </AlertDialogDescription>
                        </AlertDialogHeader>
                        <AlertDialogFooter>
                          <AlertDialogCancel className="rounded-xl">Cancelar</AlertDialogCancel>
                          <AlertDialogAction
                            onClick={() => handleDeleteTable(table.id)}
                            className="rounded-xl bg-destructive text-destructive-foreground hover:bg-destructive/90"
                          >
                            Eliminar
                          </AlertDialogAction>
                        </AlertDialogFooter>
                      </AlertDialogContent>
                    </AlertDialog>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </CardContent>

      {/* <Dialog open={customizeTable !== null} onOpenChange={() => setCustomizeTable(null)}>
        ... todo el modal de personalización ...
      </Dialog> */}

      <Dialog open={editPasswordTable !== null} onOpenChange={() => setEditPasswordTable(null)}>
        <DialogContent className="rounded-2xl">
          <DialogHeader>
            <DialogTitle>Configurar Contraseña</DialogTitle>
            <DialogDescription>
              {editPasswordTable && tables.find((t) => t.id === editPasswordTable)?.password
                ? "Cambiar la contraseña de la mesa"
                : "Agregar contraseña a la mesa"}
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="editPassword">Nueva Contraseña</Label>
              <Input
                id="editPassword"
                type="password"
                value={editPassword}
                onChange={(e) => setEditPassword(e.target.value)}
                placeholder="Dejar vacío para quitar contraseña"
                className="rounded-xl"
              />
            </div>
            <div className="flex gap-2">
              <Button
                variant="outline"
                className="flex-1 rounded-xl bg-transparent"
                onClick={() => setEditPasswordTable(null)}
              >
                Cancelar
              </Button>
              <Button
                className="flex-1 rounded-xl"
                onClick={() => editPasswordTable && handleUpdatePassword(editPasswordTable)}
              >
                Guardar
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </Card>
  )
}
