"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { PublicReservationForm } from "./PublicReservationForm"
import type { ReservationSiteConfig } from "@/src/types/reservation"
import { Calendar, Clock, Users, MapPin, Phone, Mail, CheckCircle } from "lucide-react"

interface PublicReservationSiteProps {
  barId: string
  barName: string
  config: ReservationSiteConfig
}

export function PublicReservationSite({ barId, barName, config }: PublicReservationSiteProps) {
  const [showForm, setShowForm] = useState(false)
  const [reservationSuccess, setReservationSuccess] = useState<string | null>(null)

  const handleReservationSuccess = (reservationId: string) => {
    setReservationSuccess(reservationId)
    setShowForm(false)
  }

  if (reservationSuccess) {
    return <ReservationSuccessPage reservationId={reservationSuccess} barName={barName} config={config} />
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Hero Section */}
      <section
        className="relative py-20 px-4 text-white"
        style={{
          backgroundColor: config.colorPrimary || "#3b82f6",
          backgroundImage: config.backgroundUrl ? `url(${config.backgroundUrl})` : undefined,
          backgroundSize: "cover",
          backgroundPosition: "center",
        }}
      >
        {config.backgroundUrl && <div className="absolute inset-0 bg-black/40"></div>}

        <div className="relative z-10 max-w-4xl mx-auto text-center">
          {config.logoUrl && (
            <div className="mb-6">
              <img src={config.logoUrl || "/placeholder.svg"} alt={`${barName} Logo`} className="h-16 mx-auto" />
            </div>
          )}

          <h1 className="text-4xl md:text-6xl font-bold mb-4">{config.heroTitle || "Reserva tu Mesa"}</h1>

          <p className="text-xl md:text-2xl mb-8 opacity-90">
            {config.heroSubtitle || "Disfruta de una experiencia gastronómica única"}
          </p>

          <div className="mb-8">
            <Badge variant="secondary" className="text-lg px-6 py-2 bg-white/20 text-white border-white/30">
              {barName}
            </Badge>
          </div>

          <Button
            size="lg"
            onClick={() => setShowForm(true)}
            className="bg-white text-black hover:bg-white/90 text-lg px-8 py-3"
          >
            <Calendar className="w-5 h-5 mr-2" />
            Hacer Reserva
          </Button>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-16 px-4 bg-muted/30">
        <div className="max-w-4xl mx-auto">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="text-center">
              <div className="w-16 h-16 mx-auto mb-4 rounded-full bg-primary/10 flex items-center justify-center">
                <Calendar className="w-8 h-8 text-primary" />
              </div>
              <h3 className="text-xl font-semibold mb-2">Reserva Fácil</h3>
              <p className="text-muted-foreground">Selecciona fecha, hora y número de personas en segundos</p>
            </div>

            <div className="text-center">
              <div className="w-16 h-16 mx-auto mb-4 rounded-full bg-primary/10 flex items-center justify-center">
                <Clock className="w-8 h-8 text-primary" />
              </div>
              <h3 className="text-xl font-semibold mb-2">Confirmación Inmediata</h3>
              <p className="text-muted-foreground">Recibe la confirmación al instante por SMS y email</p>
            </div>

            <div className="text-center">
              <div className="w-16 h-16 mx-auto mb-4 rounded-full bg-primary/10 flex items-center justify-center">
                <Users className="w-8 h-8 text-primary" />
              </div>
              <h3 className="text-xl font-semibold mb-2">Mesa Garantizada</h3>
              <p className="text-muted-foreground">Tu mesa estará lista cuando llegues</p>
            </div>
          </div>
        </div>
      </section>

      {/* Policies Section */}
      {config.policies && (
        <section className="py-16 px-4">
          <div className="max-w-2xl mx-auto">
            <Card>
              <CardHeader>
                <CardTitle className="text-center">Políticas de Reserva</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="whitespace-pre-line text-muted-foreground">{config.policies}</div>
              </CardContent>
            </Card>
          </div>
        </section>
      )}

      {/* Contact Section */}
      {config.contactInfo && (
        <section className="py-16 px-4 bg-muted/30">
          <div className="max-w-4xl mx-auto">
            <h2 className="text-3xl font-bold text-center mb-12">Información de Contacto</h2>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              {config.contactInfo.address && (
                <div className="text-center">
                  <div className="w-12 h-12 mx-auto mb-4 rounded-full bg-primary/10 flex items-center justify-center">
                    <MapPin className="w-6 h-6 text-primary" />
                  </div>
                  <h3 className="font-semibold mb-2">Dirección</h3>
                  <p className="text-muted-foreground">{config.contactInfo.address}</p>
                </div>
              )}

              {config.contactInfo.phone && (
                <div className="text-center">
                  <div className="w-12 h-12 mx-auto mb-4 rounded-full bg-primary/10 flex items-center justify-center">
                    <Phone className="w-6 h-6 text-primary" />
                  </div>
                  <h3 className="font-semibold mb-2">Teléfono</h3>
                  <p className="text-muted-foreground">
                    <a href={`tel:${config.contactInfo.phone}`} className="hover:text-primary">
                      {config.contactInfo.phone}
                    </a>
                  </p>
                </div>
              )}

              {config.contactInfo.email && (
                <div className="text-center">
                  <div className="w-12 h-12 mx-auto mb-4 rounded-full bg-primary/10 flex items-center justify-center">
                    <Mail className="w-6 h-6 text-primary" />
                  </div>
                  <h3 className="font-semibold mb-2">Email</h3>
                  <p className="text-muted-foreground">
                    <a href={`mailto:${config.contactInfo.email}`} className="hover:text-primary">
                      {config.contactInfo.email}
                    </a>
                  </p>
                </div>
              )}
            </div>
          </div>
        </section>
      )}

      {/* Reservation Form Modal */}
      {showForm && (
        <PublicReservationForm
          barId={barId}
          barName={barName}
          config={config}
          onClose={() => setShowForm(false)}
          onSuccess={handleReservationSuccess}
        />
      )}
    </div>
  )
}

function ReservationSuccessPage({
  reservationId,
  barName,
  config,
}: {
  reservationId: string
  barName: string
  config: ReservationSiteConfig
}) {
  return (
    <div className="min-h-screen bg-background flex items-center justify-center px-4">
      <div className="max-w-md mx-auto text-center">
        <div className="w-20 h-20 mx-auto mb-6 rounded-full bg-success/10 flex items-center justify-center">
          <CheckCircle className="w-12 h-12 text-success" />
        </div>

        <h1 className="text-3xl font-bold mb-4">¡Reserva Confirmada!</h1>

        <p className="text-muted-foreground mb-6">
          Tu reserva en <strong>{barName}</strong> ha sido confirmada exitosamente.
        </p>

        <Card>
          <CardContent className="p-6">
            <div className="space-y-2">
              <p className="text-sm text-muted-foreground">Número de Reserva</p>
              <p className="font-mono text-lg font-semibold">{reservationId.slice(-8).toUpperCase()}</p>
            </div>
          </CardContent>
        </Card>

        <div className="mt-6 space-y-2 text-sm text-muted-foreground">
          <p>Recibirás un SMS y email de confirmación en breve.</p>
          <p>Si necesitas modificar tu reserva, contacta directamente con el restaurante.</p>
        </div>

        {config.contactInfo?.phone && (
          <Button variant="outline" className="mt-6 bg-transparent" asChild>
            <a href={`tel:${config.contactInfo.phone}`}>
              <Phone className="w-4 h-4 mr-2" />
              Llamar al Restaurante
            </a>
          </Button>
        )}
      </div>
    </div>
  )
}
