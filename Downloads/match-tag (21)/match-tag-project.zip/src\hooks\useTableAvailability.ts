"use client"

import { useState, useCallback } from "react"
import { collection, query, where, getDocs } from "firebase/firestore"
import { db } from "@/src/services/firebaseConfig"
import { useAdminTables } from "./useAdminTables"

interface AvailableTable {
  id: string
  number: number
  capacity: number
  isAvailable: boolean
}

export function useTableAvailability(barId: string) {
  const [availableTables, setAvailableTables] = useState<AvailableTable[]>([])
  const [isLoading, setIsLoading] = useState(false)
  const { tables } = useAdminTables(barId)

  const getTableAvailability = useCallback(
    async (date: Date, time: string) => {
      if (!barId || !date || !time) {
        setAvailableTables([])
        return
      }

      setIsLoading(true)

      try {
        // Formatear fecha para consulta
        const dateString = date.toISOString().split("T")[0] // YYYY-MM-DD

        // Obtener reservas existentes para esa fecha y hora
        const reservationsRef = collection(db, `bars/${barId}/reservations`)
        const reservationsQuery = query(
          reservationsRef,
          where("date", "==", dateString),
          where("time", "==", time),
          where("status", "in", ["confirmed", "pending"]),
        )

        const reservationsSnapshot = await getDocs(reservationsQuery)
        const bookedTableIds = new Set<string>()

        reservationsSnapshot.forEach((doc) => {
          const reservation = doc.data()
          if (reservation.tableId) {
            bookedTableIds.add(reservation.tableId)
          }
        })

        // Crear lista de mesas disponibles
        const available: AvailableTable[] = tables
          .filter((table) => table.isActive)
          .map((table) => ({
            id: table.id,
            number: table.number,
            capacity: table.capacity || 4, // Capacidad por defecto
            isAvailable: !bookedTableIds.has(table.id),
          }))
          .filter((table) => table.isAvailable)
          .sort((a, b) => a.number - b.number)

        setAvailableTables(available)
      } catch (error) {
        console.error("Error checking table availability:", error)
        setAvailableTables([])
      } finally {
        setIsLoading(false)
      }
    },
    [barId, tables],
  )

  const isTableAvailable = useCallback(
    async (tableId: string, date: Date, time: string): Promise<boolean> => {
      if (!barId || !tableId || !date || !time) return false

      try {
        const dateString = date.toISOString().split("T")[0]

        const reservationsRef = collection(db, `bars/${barId}/reservations`)
        const reservationsQuery = query(
          reservationsRef,
          where("tableId", "==", tableId),
          where("date", "==", dateString),
          where("time", "==", time),
          where("status", "in", ["confirmed", "pending"]),
        )

        const snapshot = await getDocs(reservationsQuery)
        return snapshot.empty
      } catch (error) {
        console.error("Error checking specific table availability:", error)
        return false
      }
    },
    [barId],
  )

  return {
    availableTables,
    isLoading,
    getTableAvailability,
    isTableAvailable,
  }
}
