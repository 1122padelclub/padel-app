"use client"

import { useState, useEffect } from "react"
import { collection, query, orderBy, onSnapshot, addDoc, updateDoc, deleteDoc, doc, serverTimestamp } from "firebase/firestore"
import { db } from "@/src/services/firebaseExtras"
import type { Reservation } from "@/src/types"
import { useCRMContacts } from "./useCRMContacts"
import { validateReservation } from "@/src/utils/reservationUtils"

export function useReservations(barId: string) {
  const [reservations, setReservations] = useState<Reservation[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const { addContact } = useCRMContacts(barId)

  useEffect(() => {
    if (!barId) {
      setLoading(false)
      return
    }

    console.log("📅 Cargando reservas para barId:", barId)
    setLoading(true)

    const reservationsRef = collection(db, "bars", barId, "reservations")
    const q = query(reservationsRef, orderBy("reservationDate", "asc"), orderBy("reservationTime", "asc"))

    const unsubscribe = onSnapshot(q, (snapshot) => {
      const reservationsData: Reservation[] = []
      snapshot.forEach((doc) => {
        const data = doc.data()
        reservationsData.push({
          id: doc.id,
          ...data,
          reservationDate: data.reservationDate?.toDate() || new Date(),
          createdAt: data.createdAt?.toDate() || new Date(),
          updatedAt: data.updatedAt?.toDate() || new Date(),
        } as Reservation)
      })
      
      console.log("📅 Reservas cargadas:", reservationsData.length)
      setReservations(reservationsData)
      setLoading(false)
      setError(null)
    }, (err) => {
      console.error("❌ Error cargando reservas:", err)
      setError(err.message || "Error desconocido al cargar reservas")
      setLoading(false)
    })

    return () => unsubscribe()
  }, [barId])

  const createReservation = async (reservationData: Omit<Reservation, "id" | "createdAt" | "updatedAt">, durationMinutes: number = 120) => {
    try {
      console.log("📅 Creando reserva:", reservationData)
      
      // Validar disponibilidad antes de crear la reserva
      const validation = await validateReservation(
        barId,
        reservationData.tableId,
        reservationData.reservationDate,
        reservationData.reservationTime,
        durationMinutes
      )

      if (!validation.isValid) {
        throw new Error(validation.error || "La mesa no está disponible")
      }

      console.log("✅ Validación de disponibilidad exitosa")
      
      // Crear la reserva - limpiar campos undefined
      const cleanReservationData = {
        ...reservationData,
        // Asegurar que los campos opcionales no sean undefined
        customerEmail: reservationData.customerEmail || null,
        specialRequests: reservationData.specialRequests || null,
        notes: reservationData.notes || null,
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      }

      const reservationsRef = collection(db, "bars", barId, "reservations")
      const docRef = await addDoc(reservationsRef, cleanReservationData)

      console.log("✅ Reserva creada con ID:", docRef.id)

      // Agregar contacto al CRM automáticamente
      try {
        await addContact({
          name: reservationData.customerName,
          email: reservationData.customerEmail || "",
          phone: reservationData.customerPhone,
          source: "reservation",
          tableNumber: reservationData.tableNumber,
          comment: `Reserva para ${reservationData.partySize} personas el ${reservationData.reservationDate.toLocaleDateString()} a las ${reservationData.reservationTime}. ${reservationData.specialRequests || ""}`.trim(),
        })
        console.log("✅ Contacto agregado al CRM desde reserva")
      } catch (crmError) {
        console.error("⚠️ Error agregando contacto al CRM (reserva creada):", crmError)
        // No lanzamos el error para no afectar la creación de la reserva
      }

      return docRef.id
    } catch (err: any) {
      console.error("❌ Error creando reserva:", err)
      throw new Error(err.message || "Error desconocido al crear reserva")
    }
  }

  const updateReservation = async (reservationId: string, updates: Partial<Reservation>) => {
    try {
      const reservationRef = doc(db, "bars", barId, "reservations", reservationId)
      await updateDoc(reservationRef, {
        ...updates,
        updatedAt: serverTimestamp(),
      })
    } catch (err: any) {
      console.error("❌ Error actualizando reserva:", err)
      throw new Error(err.message || "Error desconocido al actualizar reserva")
    }
  }

  const deleteReservation = async (reservationId: string) => {
    try {
      const reservationRef = doc(db, "bars", barId, "reservations", reservationId)
      await deleteDoc(reservationRef)
    } catch (err: any) {
      console.error("❌ Error eliminando reserva:", err)
      throw new Error(err.message || "Error desconocido al eliminar reserva")
    }
  }

  const getReservationsByDate = (date: Date) => {
    const targetDate = new Date(date)
    targetDate.setHours(0, 0, 0, 0)
    const nextDay = new Date(targetDate)
    nextDay.setDate(nextDay.getDate() + 1)

    return reservations.filter(reservation => {
      const reservationDate = new Date(reservation.reservationDate)
      return reservationDate >= targetDate && reservationDate < nextDay
    })
  }

  const getReservationsByTable = (tableId: string) => {
    return reservations.filter(reservation => reservation.tableId === tableId)
  }

  const getReservationsByStatus = (status: Reservation['status']) => {
    return reservations.filter(reservation => reservation.status === status)
  }

  return {
    reservations,
    loading,
    error,
    createReservation,
    updateReservation,
    deleteReservation,
    getReservationsByDate,
    getReservationsByTable,
    getReservationsByStatus,
  }
}