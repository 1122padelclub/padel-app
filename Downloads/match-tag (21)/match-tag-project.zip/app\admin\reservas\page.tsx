"use client"

import { useSearchParams } from "next/navigation"
import { AdminReservationsPanelSimple } from "@/src/components/AdminReservationsPanelSimple"
import { Suspense } from "react"

export const dynamic = "force-dynamic"

function AdminReservasContent() {
  const sp = useSearchParams()
  const barId = sp.get("barId") ?? ""

  if (!barId) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <h1 className="text-2xl font-bold mb-4">ID de Bar Requerido</h1>
          <p className="text-muted-foreground">
            Por favor, proporciona un barId válido en la URL.
          </p>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="container mx-auto px-4 py-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">Gestión de Reservas</h1>
          <p className="text-gray-600">
            Administra las reservas del restaurante y configura el sistema de reservas.
          </p>
        </div>
        
               <AdminReservationsPanelSimple barId={barId} />
      </div>
    </div>
  )
}

export default function AdminReservasPage() {
  return (
    <Suspense fallback={
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
      </div>
    }>
      <AdminReservasContent />
    </Suspense>
  )
}